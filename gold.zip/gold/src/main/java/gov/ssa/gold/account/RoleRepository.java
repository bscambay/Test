/**
 * 
 */
package gov.ssa.gold.account;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Chris Vaughan
 *
 */
public interface RoleRepository extends JpaRepository<Role, Long> 
{

}