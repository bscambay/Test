package gov.ssa.gold;

public interface Application {}
