package gov.ssa.gold.signup;

import gov.ssa.gold.account.Account;

public class SignupForm {

	/*
	private static final String NOT_BLANK_MESSAGE = "{notBlank.message}";
	private static final String PIN_MESSAGE = "Not a valid PIN";
	private static final String PWD_MESSAGE = "Passwords must match";
	private static final String MIN_MESSAGE = "Password must be at least 6 characters";
	*/

    //@NotBlank(message = SignupForm.NOT_BLANK_MESSAGE)
	//@Size(min=6, max=6, message = SignupForm.PIN_MESSAGE)
	/*private*/ String pin;

    //@NotBlank(message = SignupForm.NOT_BLANK_MESSAGE)
    //@Size(min=6, message = SignupForm.MIN_MESSAGE)
	/*private*/ String password;
    
    //@NotBlank(message = SignupForm.NOT_BLANK_MESSAGE)
    /*private*/ String confirmPassword;
    
    /*
    @AssertTrue(message=SignupForm.PWD_MESSAGE)
    private boolean isValid() {
      return this.password.equals(this.confirmPassword);
    }
    */
    
    //@NotBlank(message = SignupForm.NOT_BLANK_MESSAGE)
    /*private*/ String name;

    public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getConfirmPassword() {
		return confirmPassword;
	}
	
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Account createAccount() {
        return new Account(getPin(), getPassword(), getName());
	}
	
}
	
