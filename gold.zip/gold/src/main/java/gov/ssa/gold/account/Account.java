package gov.ssa.gold.account;

import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name = "account")
@NamedQuery(name = Account.FIND_BY_PIN, query = "select a from Account a where a.pin = :pin")
public class Account implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -148545817118056006L;

	public static final String FIND_BY_PIN = "Account.findByPin";

	@Id
	@Column(name = "account_pin", columnDefinition = "bpchar(6)")
	private String pin;
	
	@JsonIgnore
	private String password;

	@Column(name = "name")
	private String name;
	
	@ManyToMany(fetch=FetchType.EAGER)
	@JoinTable(
			name = "account_role",
			joinColumns = @JoinColumn(name = "account_pin", referencedColumnName = "account_pin"),
			inverseJoinColumns = @JoinColumn(name = "role_id", referencedColumnName = "role_id"))
	private List<Role> roles;

    protected Account() {

	}
	
	public Account(String pin, String password, String name) {
		this.pin = pin;
		this.password = password;
		this.name = name;
	}


    public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Role> getRoles() {
		return roles;
	}

	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}

	@Override
	public String toString() {
		return String.format("pin: %s, name: %s, role count: %d", pin,name,roles.size());
		
	}
}
