package gov.ssa.gold.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import gov.ssa.gold.account.UserService;
import gov.ssa.gold.signup.SignupForm;

@Component
public class UserFormValidator implements Validator {

	@Autowired
	UserService userService;

	@Override
	public boolean supports(Class<?> clazz) {
		return SignupForm.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {

		SignupForm signupForm = (SignupForm) target;

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "pin", "NotEmpty.userForm.pin");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "NotEmpty.userForm.password");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "confirmPassword","NotEmpty.userForm.confirmPassword");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "NotEmpty.userForm.name");

		if (!signupForm.getPassword().equals(signupForm.getConfirmPassword())) {
			errors.rejectValue("confirmPassword", "Diff.userform.confirmPassword");
		}
		
		if (signupForm.getPin().length() != 6) {
			errors.rejectValue("pin", "Valid.userForm.pin");
		}

	}

}
