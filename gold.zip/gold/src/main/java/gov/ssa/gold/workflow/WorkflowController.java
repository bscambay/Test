package gov.ssa.gold.workflow;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller 
public class WorkflowController {
	
	@Autowired
	private WorkflowRepository workflowRepository;
		
	/**
	 * Get new workflow form handler
	 * @return
	 */
	@RequestMapping(value = "/workflow", method = RequestMethod.GET)
	public String workflow(){
		return "workflow/new";
	}
	
	@RequestMapping(value="/workflow/save", method=RequestMethod.POST)
	public String createWorkflow() {
		
		Workflow workflow = new Workflow();
		
		// Populate with the values from the client
				
		workflowRepository.save(workflow);
		
		return "Success";		
	}
	
}