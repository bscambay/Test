package gov.ssa.gold.workflow;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="workflow")
public class Workflow {

// TODO (Keith & Jon) Pull account instead of account PIN
//	FOREIGN KEY (created_by) REFERENCES account(account_pin), --joins to account table
//	FOREIGN KEY (last_modified_by) REFERENCES account(account_pin) --joins to account table
	
	@Id
	@Column(name="workflow_id")
	private Long id;
	
	private String name;
	
	@Column(name="last_modified_by", columnDefinition="bpchar(6)")
	private String lastModifiedBy;
	
	@Column(name="last_modified")
	private Timestamp lastModified;
	
	private Timestamp created;
	
	private String description;
	
	@Column(name="created_by", columnDefinition="bpchar(6)")
	private String createdBy;

	public Workflow() {
		// TODO Auto-generated constructor stub
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModified() {
		return lastModified;
	}

	public void setLastModified(Timestamp lastModified) {
		this.lastModified = lastModified;
	}

	public Timestamp getCreated() {
		return created;
	}

	public void setCreated(Timestamp created) {
		this.created = created;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	// TODO (Keith & Jon) Learn how to create an entity base class

	@Override
	public String toString() {
		return "Workflow [workflow_id=" + id + ", name=" + name + ", lastModifiedBy=" + lastModifiedBy
				+ ", lastModified=" + lastModified + ", created=" + created + ", description=" + description
				+ ", createdBy=" + createdBy + "]";
	}	
}