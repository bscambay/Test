/**
 * 
 */
package gov.ssa.gold.account;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Controller for managing roles
 * @author Chris Vaughan
 */
@Controller
public class RoleController 
{
	@Autowired
	private RoleRepository roleRepository;
	
	/**
	 * Handle request to view all roles
	 * @param model
	 * @return
	 */
	@RequestMapping(value="roles")
	public String getRoles(Model model)
	{
		model.addAttribute("roles", roleRepository.findAll());
	
		return "roles/roles";
	}
	
	/**
	 * Handle request to get new role form
	 * @return
	 */
	@RequestMapping(value="roles/new")
	public String getNewRole()
	{
		return "roles/newRole";
	}
}