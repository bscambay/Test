var app = angular.module("myApp", ["ngRoute"]);

app.config(function($routeProvider) {
	$routeProvider.when("/workflow", {
		templateUrl : "./resources/static/workflow/workflow.html"
    }).when('/roles', {
    	templateUrl: "roles"
    }).when('/newRole', {
    	templateUrl: "roles/new"
    });
});
				
				
				