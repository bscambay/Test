# INSIGHT COMMON CALCULATIONS:
#
# AUTHOR:
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 09.09.2016
#
# SUMMARY:
# Contains functions that perform miscellaneous/common calculation tasks
# required by INSIGHT modules.
#
# PRIORITY TODOS: Once you resolve questions about how to best structured
# the Version 2 'PAI' and 'age' data points (per Robyn/Jimmy's feedback),
# incorporate that structure into the functions below.
#
# WARNING:
# The following is alpha-level/prototype software whose output quality has
# not yet been formally validated and whose documentation is not yet fully
# formed.
# =============================================================================

import logging
import os.path
from operator import itemgetter

from dateutil.relativedelta import relativedelta

import date_helper as dh
import iqrgenerator.iqrgenerator_common_calcs as ifsiqrcc

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
logdir = os.path.join(insightdir, "Log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


# Convert structured data observation claim/disposition data
# into a standardized list of 'single claim' dicts containing
# structured data values (aside from 'CLM_TYP', which is a parsed
# value):
def convert_struct_claimdisp(input_df):
    '''Convert ARCHWKUT structured data observations
    into a more 'claimdisp'-like, individual claim-centric
    series of observations.

    REMINDER: If called on data generated from
    batch_struct_data_retrievers.py or from IFS DB retrieval,
    then every date value will either be ##/##/#### or 'E', with
    'E' covering blanks.

    Args:
        input_df {Pandas DataFrame}: The row(s) associated
            with a target DOCU_CTL_ID/REQID value.
    Returns:
        struct_claimdisp_resdictlist {list}: A list of
            dicts, each dict representing
            an individual claim. An INSIGHT observations
            'CLAIMDISP_STRUCT' value.

            Each dict contains the following keys:
            CLM_TYP: A more fully written, precise claim type
                value.  Value options =
                'T2 DWB'
                'T2 CDB'
                'T2 DIB Termination'
                'T2 DIB'
                'T16 SSI Termination (Type Unknown)'
                'T16 SSI Termination'
                'T16 SSI Termination Child'
                'T16 SSI (Type Unknown)'
                'T16 SSI Adult+Child'
                'T16 SSI Child'
                'T16 SSI'
                [A structured CLM_TYP value, e.g. one in ARCHWKUT.CLM_TYP]
            APP_DT: Structured app date value appropriate for the CLM_TYP title (e.g. 'T2_APP_DT' for a CLM_TYP of 'T2 DIB')
            PFLG_DT: Structured protective filing date value appropriate for the CLM_TYP title
            ALLGD_DISB_ONST_DT: AOD value
            DLI: DLI value
            FNL_DSPN_DT: FNL_DSPN_DT value
            DSPN_CD: Structured disposition code value appropriate for the CLM_TYP title
            PRTL_FFVRBL_CD: Structured partially/fully favorable code value appropriate for the CLM_TYP title
    Raises:
        N/A (returns empty list if exception).
    '''
    try:
        struct_claimdisp_resdictlist = []
        for i, row in input_df.iterrows():

            # Get CL age at FNL_DSPN_DT:
            clmt_age_fnl_dspn_dt = dh.calc_age(row['CLMT_DOB'], row['FNL_DSPN_DT'])

            clm_typ = row['CLM_TYP']

            # Parse T2 DWB:
            if clm_typ == 'DIWW':
                resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                           'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                resdict['CLM_TYP'] = 'T2 DWB'
                resdict['APP_DT'] = row['T2_APP_DT']
                resdict['PFLG_DT'] = row['T2_PFLG_DT']
                resdict['DSPN_CD'] = row['T2_DSPN_CD']
                resdict['PRTL_FFVRBL_CD'] = row['T2_PRTL_FFVRBL_CD']
                struct_claimdisp_resdictlist.append(resdict)

            # Parse T2 DIB:
            # TIP: No instances where a 'DIWC' value is
            # paired with a 'W' BIC variant.
            elif clm_typ == 'DIWC':
                if row['BIC'].startswith('C'):
                    resdict = {}
                    resdict['CLM_TYP'] = 'T2 CDB'
                    resdict['APP_DT'] = row['T2_APP_DT']
                    resdict['PFLG_DT'] = row['T2_PFLG_DT']
                    resdict['ALLGD_DISB_ONST_DT'] = row['ALLGD_DISB_ONST_DT']
                    resdict['DLI'] = row['DLI']
                    resdict['FNL_DSPN_DT'] = row['FNL_DSPN_DT']
                    resdict['DSPN_CD'] = row['T2_DSPN_CD']
                    resdict['PRTL_FFVRBL_CD'] = row['T2_PRTL_FFVRBL_CD']
                    struct_claimdisp_resdictlist.append(resdict)
                else:
                    if row['HRG_TYP'].endswith('1') or row['HRG_TYP'].endswith('3') or row['HRG_TYP'].endswith('6'):
                        resdict = {}
                        resdict['CLM_TYP'] = 'T2 DIB Termination'
                        resdict['APP_DT'] = row['T2_APP_DT']
                        resdict['PFLG_DT'] = row['T2_PFLG_DT']
                        resdict['ALLGD_DISB_ONST_DT'] = row['ALLGD_DISB_ONST_DT']
                        resdict['DLI'] = row['DLI']
                        resdict['FNL_DSPN_DT'] = row['FNL_DSPN_DT']
                        resdict['DSPN_CD'] = row['T2_DSPN_CD']
                        resdict['PRTL_FFVRBL_CD'] = row['T2_PRTL_FFVRBL_CD']
                        struct_claimdisp_resdictlist.append(resdict)
                    else:
                        resdict = {}
                        resdict['CLM_TYP'] = 'T2 DIB'
                        resdict['APP_DT'] = row['T2_APP_DT']
                        resdict['PFLG_DT'] = row['T2_PFLG_DT']
                        resdict['ALLGD_DISB_ONST_DT'] = row['ALLGD_DISB_ONST_DT']
                        resdict['DLI'] = row['DLI']
                        resdict['FNL_DSPN_DT'] = row['FNL_DSPN_DT']
                        resdict['DSPN_CD'] = row['T2_DSPN_CD']
                        resdict['PRTL_FFVRBL_CD'] = row['T2_PRTL_FFVRBL_CD']
                        struct_claimdisp_resdictlist.append(resdict)

            # Parse T16 SSI:
            elif clm_typ == 'SSID':
                if row['HRG_TYP'].endswith('1') or row['HRG_TYP'].endswith('3') or row['HRG_TYP'].endswith('6'):
                    if clmt_age_fnl_dspn_dt == 'E':
                        resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                                   'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                        resdict['CLM_TYP'] = 'T16 SSI Termination (Type Unknown)'
                        resdict['APP_DT'] = row['T16_APP_DT']
                        resdict['PFLG_DT'] = row['T16_PFLG_DT']
                        resdict['DSPN_CD'] = row['T16_DSPN_CD']
                        resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                        struct_claimdisp_resdictlist.append(resdict)
                    else:
                        if int(clmt_age_fnl_dspn_dt.split('-')[0]) >= 18:
                            resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                                       'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                            resdict['CLM_TYP'] = 'T16 SSI Termination'
                            resdict['APP_DT'] = row['T16_APP_DT']
                            resdict['PFLG_DT'] = row['T16_PFLG_DT']
                            resdict['DSPN_CD'] = row['T16_DSPN_CD']
                            resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                            struct_claimdisp_resdictlist.append(resdict)
                        else:
                            resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                                       'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                            resdict['CLM_TYP'] = 'T16 SSI Termination Child'
                            resdict['APP_DT'] = row['T16_APP_DT']
                            resdict['PFLG_DT'] = row['T16_PFLG_DT']
                            resdict['DSPN_CD'] = row['T16_DSPN_CD']
                            resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                            struct_claimdisp_resdictlist.append(resdict)
                else:
                    if clmt_age_fnl_dspn_dt == 'E':
                        resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                                   'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                        resdict['CLM_TYP'] = 'T16 SSI (Type Unknown)'
                        resdict['APP_DT'] = row['T16_APP_DT']
                        resdict['PFLG_DT'] = row['T16_PFLG_DT']
                        resdict['DSPN_CD'] = row['T16_DSPN_CD']
                        resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                        struct_claimdisp_resdictlist.append(resdict)
                    else:
                        if int(clmt_age_fnl_dspn_dt.split('-')[0]) >= 18:

                            clmt_age_t16_app_dt_ultimate = 'E'
                            if row['T16_PFLG_DT'] != 'E':
                                clmt_age_t16_app_dt_ultimate = dh.calc_age(row['CLMT_DOB'], row['T16_PFLG_DT'])
                            else:
                                clmt_age_t16_app_dt_ultimate = dh.calc_age(row['CLMT_DOB'], row['T16_APP_DT'])

                            if clmt_age_t16_app_dt_ultimate == 'E':
                                resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                                           'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                                resdict['CLM_TYP'] = 'T16 SSI (Type Unknown)'
                                resdict['APP_DT'] = row['T16_APP_DT']
                                resdict['PFLG_DT'] = row['T16_PFLG_DT']
                                resdict['DSPN_CD'] = row['T16_DSPN_CD']
                                resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                                struct_claimdisp_resdictlist.append(resdict)
                            else:
                                clmt_age_t16_app_dt_ultimate_yr = clmt_age_t16_app_dt_ultimate.split('-')[0]
                                if clmt_age_t16_app_dt_ultimate_yr >= 18:
                                    resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                                               'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                                    resdict['CLM_TYP'] = 'T16 SSI'
                                    resdict['APP_DT'] = row['T16_APP_DT']
                                    resdict['PFLG_DT'] = row['T16_PFLG_DT']
                                    resdict['DSPN_CD'] = row['T16_DSPN_CD']
                                    resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                                    struct_claimdisp_resdictlist.append(resdict)
                                else:
                                    resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                                               'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                                    resdict['CLM_TYP'] = 'T16 SSI Adult+Child'
                                    resdict['APP_DT'] = row['T16_APP_DT']
                                    resdict['PFLG_DT'] = row['T16_PFLG_DT']
                                    resdict['DSPN_CD'] = row['T16_DSPN_CD']
                                    resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                                    struct_claimdisp_resdictlist.append(resdict)
                        else:
                            resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                                       'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                            resdict['CLM_TYP'] = 'T16 SSI Child'
                            resdict['APP_DT'] = row['T16_APP_DT']
                            resdict['PFLG_DT'] = row['T16_PFLG_DT']
                            resdict['DSPN_CD'] = row['T16_DSPN_CD']
                            resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                            struct_claimdisp_resdictlist.append(resdict)

            # Parse concurrent observations:
            elif clm_typ == 'SSDC':
                # Parse T2 portion:
                if row['BIC'].startswith('C'):
                    resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                               'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                    resdict['CLM_TYP'] = 'T2 CDB'
                    resdict['APP_DT'] = row['T2_APP_DT']
                    resdict['PFLG_DT'] = row['T2_PFLG_DT']
                    resdict['DSPN_CD'] = row['T2_DSPN_CD']
                    resdict['PRTL_FFVRBL_CD'] = row['T2_PRTL_FFVRBL_CD']
                    struct_claimdisp_resdictlist.append(resdict)
                elif row['BIC'].startswith('W'):
                    resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                               'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                    resdict['CLM_TYP'] = 'T2 DWB'
                    resdict['APP_DT'] = row['T2_APP_DT']
                    resdict['PFLG_DT'] = row['T2_PFLG_DT']
                    resdict['DLI'] = row['DLI']
                    resdict['DSPN_CD'] = row['T2_DSPN_CD']
                    resdict['PRTL_FFVRBL_CD'] = row['T2_PRTL_FFVRBL_CD']
                    struct_claimdisp_resdictlist.append(resdict)
                else:
                    if row['HRG_TYP'].endswith('1') or row['HRG_TYP'].endswith('3') or row['HRG_TYP'].endswith('6'):
                        resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                                   'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                        resdict['CLM_TYP'] = 'T2 DIB Termination'
                        resdict['APP_DT'] = row['T2_APP_DT']
                        resdict['DLI'] = row['DLI']
                        resdict['PFLG_DT'] = row['T2_PFLG_DT']
                        resdict['DSPN_CD'] = row['T2_DSPN_CD']
                        resdict['PRTL_FFVRBL_CD'] = row['T2_PRTL_FFVRBL_CD']
                        struct_claimdisp_resdictlist.append(resdict)
                    else:
                        resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                                   'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                        resdict['CLM_TYP'] = 'T2 DIB'
                        resdict['APP_DT'] = row['T2_APP_DT']
                        resdict['DLI'] = row['DLI']
                        resdict['PFLG_DT'] = row['T2_PFLG_DT']
                        resdict['DSPN_CD'] = row['T2_DSPN_CD']
                        resdict['PRTL_FFVRBL_CD'] = row['T2_PRTL_FFVRBL_CD']
                        struct_claimdisp_resdictlist.append(resdict)

                # Parse T16 portion:
                if row['HRG_TYP'].endswith('1') or row['HRG_TYP'].endswith('3') or row['HRG_TYP'].endswith('6'):
                    if clmt_age_fnl_dspn_dt == 'E':
                        resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                                   'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                        resdict['CLM_TYP'] = 'T16 SSI Termination (Type Unknown)'
                        resdict['APP_DT'] = row['T16_APP_DT']
                        resdict['PFLG_DT'] = row['T16_PFLG_DT']
                        resdict['DSPN_CD'] = row['T16_DSPN_CD']
                        resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                        struct_claimdisp_resdictlist.append(resdict)
                    else:
                        if int(clmt_age_fnl_dspn_dt.split('-')[0]) >= 18:
                            resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                                       'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                            resdict['CLM_TYP'] = 'T16 SSI Termination'
                            resdict['APP_DT'] = row['T16_APP_DT']
                            resdict['PFLG_DT'] = row['T16_PFLG_DT']
                            resdict['DSPN_CD'] = row['T16_DSPN_CD']
                            resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                            struct_claimdisp_resdictlist.append(resdict)
                        else:
                            resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                                       'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                            resdict['CLM_TYP'] = 'T16 SSI Termination Child'
                            resdict['APP_DT'] = row['T16_APP_DT']
                            resdict['PFLG_DT'] = row['T16_PFLG_DT']
                            resdict['DSPN_CD'] = row['T16_DSPN_CD']
                            resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                            struct_claimdisp_resdictlist.append(resdict)
                else:
                    if clmt_age_fnl_dspn_dt == 'E':
                        resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                                   'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                        resdict['CLM_TYP'] = 'T16 SSI (Type Unknown)'
                        resdict['APP_DT'] = row['T16_APP_DT']
                        resdict['PFLG_DT'] = row['T16_PFLG_DT']
                        resdict['DSPN_CD'] = row['T16_DSPN_CD']
                        resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                        struct_claimdisp_resdictlist.append(resdict)
                    else:
                        if int(clmt_age_fnl_dspn_dt.split('-')[0]) >= 18:
                            clmt_age_t16_app_dt_ultimate = dh.calc_age(row['CLMT_DOB'], row['T16_APP_DT'])
                            if row['T16_PFLG_DT']:
                                clmt_age_t16_app_dt_ultimate = dh.calc_age(row['CLMT_DOB'], row['T16_PFLG_DT'])

                            if clmt_age_t16_app_dt_ultimate == 'E':
                                resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                                           'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                                resdict['CLM_TYP'] = 'T16 SSI (Type Unknown)'
                                resdict['APP_DT'] = row['T16_APP_DT']
                                resdict['PFLG_DT'] = row['T16_PFLG_DT']
                                resdict['DSPN_CD'] = row['T16_DSPN_CD']
                                resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                                struct_claimdisp_resdictlist.append(resdict)
                            else:
                                clmt_age_t16_app_dt_ultimate_yr = int(clmt_age_t16_app_dt_ultimate.split('-')[0])
                                if clmt_age_t16_app_dt_ultimate_yr >= 18:
                                    resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                                               'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                                    resdict['CLM_TYP'] = 'T16 SSI'
                                    resdict['APP_DT'] = row['T16_APP_DT']
                                    resdict['PFLG_DT'] = row['T16_PFLG_DT']
                                    resdict['DSPN_CD'] = row['T16_DSPN_CD']
                                    resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                                    struct_claimdisp_resdictlist.append(resdict)
                                else:
                                    resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                                               'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                                    resdict['CLM_TYP'] = 'T16 SSI Adult+Child'
                                    resdict['APP_DT'] = row['T16_APP_DT']
                                    resdict['PFLG_DT'] = row['T16_PFLG_DT']
                                    resdict['DSPN_CD'] = row['T16_DSPN_CD']
                                    resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                                    struct_claimdisp_resdictlist.append(resdict)
                        else:
                            resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                                       'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                            resdict['CLM_TYP'] = 'T16 SSI Child'
                            resdict['APP_DT'] = row['T16_APP_DT']
                            resdict['PFLG_DT'] = row['T16_PFLG_DT']
                            resdict['DSPN_CD'] = row['T16_DSPN_CD']
                            resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                            struct_claimdisp_resdictlist.append(resdict)

            # Output 'U' for all other values that are T2/T16-dependent:
            else:
                resdict = {'ALLGD_DISB_ONST_DT':row['ALLGD_DISB_ONST_DT'], 'DLI':row['DLI'],
                           'FNL_DSPN_DT':row['FNL_DSPN_DT']}
                resdict['CLM_TYP'] = 'U'
                resdict['APP_DT'] = 'U'
                resdict['PFLG_DT'] = 'U'
                resdict['DSPN_CD'] = 'U'
                resdict['PRTL_FFVRBL_CD'] = 'U'
                struct_claimdisp_resdictlist.append(resdict)

        # Return results:
        return struct_claimdisp_resdictlist

    except Exception:
        logger.exception('EXCEPTION')
        return []


# Parse 'CLAIMDISP_STRUCT' list of dicts to add in a more salient/
# parsed disposition type values:
def parse_disp_type_struct(input_dictlist):
    '''Output a disposition type translation for the INSIGHT
    Web App by parsing an INSIGHT 'CLAIMDISP_STRUCT' list
    of dictionaries value.

    Args:
        input_dictlist {list}: A list of dicts where each
            dict contains structured data re: a claim. This is
            designed to be the output of convert_struct_claimdisp().
    Returns:
        dictlist_parsed {list}: A list of dicts with a parsed
            'disptype' value added to each.
    Raises:
        N/A (returns input list of dicts with each 'disptype'
        value being 'Error' if exception occurs).
    '''
    try:
        dictlist_parsed = []
        for subd in input_dictlist:
            if subd['DSPN_CD'] in ['FAFF', 'FREV']:
                prtl_ffvrbl_cd = subd['PRTL_FFVRBL_CD'].strip()
                if prtl_ffvrbl_cd == 'F':
                    subd['disptype'] = "Fully Favorable"
                    dictlist_parsed.append(subd)
                elif subd['PRTL_FFVRBL_CD'] in ['L', 'C']:
                    subd['disptype'] = "Partially Favorable"
                    dictlist_parsed.append(subd)
                else:
                    subd['disptype'] = "Favorable"
                    dictlist_parsed.append(subd)
            elif subd['DSPN_CD'] in ['UAFF', 'UREV']:
                subd['disptype'] = "Unfavorable"
                dictlist_parsed.append(subd)
            elif 'DI' in subd['DSPN_CD']:
                subd['disptype'] = "Dismissal"
                dictlist_parsed.append(subd)
            else:
                subd['disptype'] = "Unknown"
                dictlist_parsed.append(subd)
        return dictlist_parsed
    except Exception:
        logger.exception('EXCEPTION')
        dictlist_parsed = []
        for subd in input_dictlist:
            subd['disptype'] = 'Error'
            dictlist_parsed.append(subd)
        return dictlist_parsed


# Calculate 'STRUCT_AGEREL_PAISTART' and 'paistart':
def calc_struct_agerel_paistart(input_dict):
    '''Calculate the start of a claim entity's
    period at issue (PAI) and their age at that
    date using largely structured data except for
    some (arguably more accurate) INSIGHT dates.

    Args:
        input_dict {dict}: An INSIGHT observation
            dictionary containing 'CLAIMDISP_STRUCT'.
    Returns:
        struct_agerel_paistart {str}: The claimant's
            age at the start of the PAI. If unable
            to calculate, 'E' is assigned.
        struct_agerel_paistart_src {str}: An indicator
            for the data used to derive the 'paistart'
            and its age value.  '0' means a preferred/
            primary source was used; '1' means a secondary
            source was used.  As a general rule, sources
            deemed 'primary' are more reliable/accurate than
            secondary sources.
        paistart_candidate_list_min {str}: The start
            of the claim entity PAI. If unable to
            calculate, 'E' is assigned.
    Raises:
        N/A (returns 'E' values if exception occurs).
    '''
    try:

        # Verify non-empty presence of CLAIMDISP_STRUCT subdicts:
        claimdisp_struct = input_dict['CLAIMDISP_STRUCT']
        if not claimdisp_struct:
            return 'E', 'E', 'E'

        # Verify presence of required CLMT_DOB value, and if present, convert to DT:
        # TIP: 'U' if batch.py found 2 different CLMT_DOB values; 'E' if date
        # conversion failed or CLMT_DOB was empty at conversion in
        # batch_struct_data_retrievers.py.
        try:
            structdob = input_dict['CLMT_DOB']
        except KeyError:
            structdoblist = ifsiqrcc.gather_container_tgt(input_dict, 'struct_hodisp', 'CLMT_DOB', 'U', 'U', 'U')
            if not structdoblist:
                structdob = 'U'
            else:
                if len(list(set(structdoblist))) == 1:
                    structdob = structdoblist[0]
                else:
                    structdob = 'U'

        if structdob in ['U', 'E']:
            return 'E', 'E', 'E'

        structdob_dt = dh.parse_date_todatetime_struct(structdob)
        if structdob_dt == 'E':
            return 'E', 'E', 'E'

        # Filter out dismissed claims (no effect on PAI):
        claimdisp_struct = [subd for subd in claimdisp_struct if 'DI' not in subd['DSPN_CD']]
        if not claimdisp_struct:
            return 'E', 'E', 'E'

        # Find the PAI start value for each claim:
        paistart_candidate_list = []

        # Parse INSIGHT-derived AOD values:
        insight_aodlist = []
        if input_dict['aod'] not in ['U', 'P', 'E', '']:
            for aodval in input_dict['aod'].split('; '):
                insight_aodlist.append(dh.parse_date_todatetime_struct(aodval))
        # TIP: If multiple values, retrieve most recent (on
        # SME-based assumption that it likely represents
        # an amended AOD):
        insight_aodlist_max = 'U'
        if insight_aodlist:
            if 'E' not in insight_aodlist and 'U' not in insight_aodlist:
                insight_aodlist_max = max(insight_aodlist)

        # Iterate through structured claim data to generate 'paistart' candidates:
        for subd in claimdisp_struct:

            claimtype = subd['CLM_TYP']

            if claimtype in ['T2 DIB', 'T2 DIB Termination']:
                if insight_aodlist_max != 'U':
                    paistart_candidate_list.append((dh.parse_datetime_to_ifs_date(insight_aodlist_max), '0'))
                else:
                    if subd['ALLGD_DISB_ONST_DT'] not in ['U', 'E']:
                        paistart_candidate_list.append((subd['ALLGD_DISB_ONST_DT'], '1'))
                    else:
                        paistart_candidate_list.append(('E', 'E'))

            elif claimtype == 'T2 CDB':
                age18_dt = structdob_dt + relativedelta(years=18)
                if insight_aodlist_max != 'U':
                    if insight_aodlist_max > age18_dt:
                        paistart_candidate_list.append((dh.parse_datetime_to_ifs_date(insight_aodlist_max), '0'))
                    else:
                        paistart_candidate_list.append((dh.parse_datetime_to_ifs_date(age18_dt), '0'))
                else:
                    if subd['ALLGD_DISB_ONST_DT'] not in ['U', 'E']:
                        if dh.parse_date_todatetime_struct(subd['ALLGD_DISB_ONST_DT']) > age18_dt:
                            paistart_candidate_list.append((subd['ALLGD_DISB_ONST_DT'], '1'))
                        else:
                            paistart_candidate_list.append((dh.parse_datetime_to_ifs_date(age18_dt), '1'))
                    else:
                        paistart_candidate_list.append(('E', 'E'))

            elif claimtype == 'T2 DWB':
                age50_dt = dh.parse_date_todatetime_struct(structdob) + relativedelta(years=50)
                if insight_aodlist_max != 'U':
                    if insight_aodlist_max > age50_dt:
                        paistart_candidate_list.append((dh.parse_datetime_to_ifs_date(insight_aodlist_max), '0'))
                    else:
                        paistart_candidate_list.append((dh.parse_datetime_to_ifs_date(age50_dt), '0'))
                else:
                    if subd['ALLGD_DISB_ONST_DT'] not in ['U', 'E']:
                        if dh.parse_date_todatetime_struct(subd['ALLGD_DISB_ONST_DT']) > age50_dt:
                            paistart_candidate_list.append((subd['ALLGD_DISB_ONST_DT'], '1'))
                        else:
                            paistart_candidate_list.append((dh.parse_datetime_to_ifs_date(age50_dt), '1'))
                    else:
                        paistart_candidate_list.append(('E', 'E'))

            elif claimtype in ['T16 SSI', 'T16 SSI Child', 'T16 SSI Child+Adult']:

                dof_min = 'U'
                dof_list = [dh.parse_date_todatetime_struct(d) for d in [subd['APP_DT'], subd['PFLG_DT']]]
                dof_list_non_e = [ne for ne in dof_list if ne != 'E']
                if dof_list_non_e:
                    dof_min = min([dh.parse_date_todatetime_struct(d) for d in dof_list_non_e])

                if dof_min == 'U':
                    paistart_candidate_list.append(('E', 'E'))
                else:
                    if insight_aodlist_max != 'U':
                        if insight_aodlist_max > dof_min:
                            paistart_candidate_list.append((dh.parse_datetime_to_ifs_date(insight_aodlist_max), '0'))
                        else:
                            paistart_candidate_list.append((dh.parse_datetime_to_ifs_date(dof_min), '0'))
                    else:
                        if subd['ALLGD_DISB_ONST_DT'] in ['U', 'E']:
                            paistart_candidate_list.append(('E', 'E'))
                        else:
                            if dh.parse_date_todatetime_struct(subd['ALLGD_DISB_ONST_DT']) > dof_min:
                                paistart_candidate_list.append((subd['ALLGD_DISB_ONST_DT'], '1'))
                            else:
                                paistart_candidate_list.append((dh.parse_datetime_to_ifs_date(dof_min), '1'))

            # If a termination of some sort, the start of the PAI are dates like the date
            # the claimant was found no longer disabled, the date they turned 18, etc.  As we
            # don't have that as a data point, output 'E':
            else:
                paistart_candidate_list.append(('E', 'E'))

        # If any 'E' values in paistart_candidate_list, then logically cannot be sure of
        # paistart or struct_agerel_paistart; output 'E':
        if 'E' in [tup[0] for tup in paistart_candidate_list]:
            return 'E', 'E', 'E'

        # Convert paistart_candidate_list entries into DT objects:
        paistart_candidate_list_dt = [(dh.parse_date_todatetime_struct(d[0]), d[1]) for d in paistart_candidate_list]

        # If paistart_candidate_list_dt or a conversion failed ('E'), then
        # cannot be certain of PAI start; return 'E' values:
        if not paistart_candidate_list_dt or 'E' in [tup[0] for tup in paistart_candidate_list_dt]:
            return 'E', 'E', 'E'

        # Find earliest PAI start date across claims:
        paistart_candidate_list_min_tup = min(paistart_candidate_list_dt, key=itemgetter(0))

        # Calculate age from that earliest point:
        struct_agerel_paistart = dh.calc_age(structdob_dt, paistart_candidate_list_min_tup[0])

        # Return struct_agerel_paistart and paistart:
        return struct_agerel_paistart, paistart_candidate_list_min_tup[1], dh.parse_datetime_to_ifs_date(
            paistart_candidate_list_min_tup[0])

    except Exception:
        logger.exception('EXCEPTION')
        return 'E', 'E', 'E'


# Calculate 'STRUCT_AGEREL_PAIEND' and 'paiend':
def calc_struct_agerel_paiend(input_dict):
    '''Calculate the end of a claim entity's
    period at issue (PAI) and their age at that
    date using largely structured data except for
    some (arguably more accurate) INSIGHT dates.

    Args:
        input_dict {dict}: An INSIGHT observation
            dictionary containing 'CLAIMDISP_STRUCT'.
    Returns:
        struct_agerel_paiend {str}: The claimant's
            age at the end of the PAI. If unable
            to calculate, 'E' is assigned.
        struct_agerel_paiend_src {str}: An indicator
            for the data used to derive the 'paistart'
            and its age value.  '0' means a preferred/
            primary source was used; '1' means a secondary
            source was used.  As a general rule, sources
            deemed 'primary' are more reliable/accurate than
            secondary sources.
        paistart_candidate_list_min {str}: The end
            of the claim entity PAI. If unable to
            calculate, 'E' is assigned.
    Raises:
        N/A (returns 'E' values if exception occurs).
    '''
    try:

        # Verify non-empty presence of CLAIMDISP_STRUCT subdicts:
        claimdisp_struct = input_dict['CLAIMDISP_STRUCT']
        if not claimdisp_struct:
            return 'E', 'E', 'E'

        # Verify presence of required CLMT_DOB value, and if present, convert to DT:
        # TIP: 'U' if batch.py found 2 different CLMT_DOB values; 'E' if date
        # conversion failed or CLMT_DOB was empty at conversion in
        # batch_struct_data_retrievers.py.
        structdob = 'U'
        try:
            structdob = input_dict['CLMT_DOB']
        except KeyError:
            structdoblist = ifsiqrcc.gather_container_tgt(input_dict, 'struct_hodisp', 'CLMT_DOB', 'U', 'U', 'U')
            if not structdoblist:
                structdob = 'U'
            else:
                if len(list(set(structdoblist))) == 1:
                    structdob = structdoblist[0]
                else:
                    structdob = 'U'

        if structdob in ['U', 'E']:
            return 'E', 'E', 'E'
        structdob_dt = dh.parse_date_todatetime_struct(structdob)
        if structdob_dt == 'E':
            return 'E', 'E', 'E'

        # Filter out dismissed claims (no effect on PAI):
        claimdisp_struct = [subd for subd in claimdisp_struct if 'DI' not in subd['DSPN_CD']]
        if not claimdisp_struct:
            return 'E', 'E', 'E'

        # Find the PAI end value for each claim:
        paiend_candidate_list = []

        # Parse INSIGHT-derived DLI values and if
        # multiple values, retrieve highest (on
        # SME-based assumption that later DLI is more
        # likely to be authoritative):
        insight_dli_list = []
        if input_dict['dli'] not in ['U', 'P', 'E', '']:
            for dli in input_dict['dli'].split('; '):
                insight_dli_list.append(dh.parse_date_todatetime_struct(dli))
        insight_dli_list_max = 'U'
        if insight_dli_list:
            if 'E' not in insight_dli_list and 'U' not in insight_dli_list:
                insight_dli_list_max = max(insight_dli_list)

        did_parsed = 'U'
        if input_dict['did'] not in ['U', 'P', 'E', ''] and ';' not in input_dict['did']:
            did_parsed = input_dict['did']

        for subd in claimdisp_struct:

            claimtype = subd['CLM_TYP']

            if 'T2 DIB' in claimtype:

                if insight_dli_list_max != 'U':
                    if did_parsed != 'U':
                        if insight_dli_list_max < dh.parse_date_todatetime_struct(did_parsed):
                            paiend_candidate_list.append((dh.parse_datetime_to_ifs_date(insight_dli_list_max), '0'))
                        else:
                            paiend_candidate_list.append((did_parsed, '0'))
                    else:
                        if subd['FNL_DSPN_DT'] not in ['U', 'E']:
                            if insight_dli_list_max < dh.parse_date_todatetime_struct(subd['FNL_DSPN_DT']):
                                paiend_candidate_list.append((dh.parse_datetime_to_ifs_date(insight_dli_list_max), '1'))
                            else:
                                paiend_candidate_list.append((subd['FNL_DSPN_DT'], '1'))
                        else:
                            paiend_candidate_list.append(('E', 'E'))
                else:
                    if subd['DLI'] not in ['U', 'E']:
                        if did_parsed != 'U':
                            if dh.parse_date_todatetime_struct(subd['DLI']) < dh.parse_date_todatetime_struct(
                                    did_parsed):
                                paiend_candidate_list.append((subd['DLI'], '1'))
                            else:
                                paiend_candidate_list.append((did_parsed, '1'))
                        else:
                            if subd['FNL_DSPN_DT'] not in ['U', 'E']:
                                if dh.parse_date_todatetime_struct(subd['DLI']) < dh.parse_date_todatetime_struct(
                                        subd['FNL_DSPN_DT']):
                                    paiend_candidate_list.append((subd['DLI'], '1'))
                                else:
                                    paiend_candidate_list.append((subd['FNL_DSPN_DT'], '1'))
                            else:
                                paiend_candidate_list.append(('E', 'E'))
                    else:
                        paiend_candidate_list.append(('E', 'E'))

            elif 'T2 CDB' in claimtype:
                age22_dt = structdob_dt + relativedelta(years=22)
                if did_parsed != 'U':
                    if dh.parse_date_todatetime_struct(did_parsed) > age22_dt:
                        paiend_candidate_list.append((dh.parse_datetime_to_ifs_date(age22_dt), '0'))
                    else:
                        paiend_candidate_list.append((did_parsed, '0'))
                else:
                    if subd['FNL_DSPN_DT'] not in ['U', 'E']:
                        if dh.parse_date_todatetime_struct(subd['FNL_DSPN_DT']) > age22_dt:
                            paiend_candidate_list.append((dh.parse_datetime_to_ifs_date(age22_dt), '1'))
                        else:
                            paiend_candidate_list.append((subd['FNL_DSPN_DT'], '1'))
                    else:
                        paiend_candidate_list.append(('E', 'E'))

            elif 'T2 DWB' in claimtype:
                age60_dt = structdob_dt + relativedelta(years=60)
                if did_parsed != 'U':
                    if dh.parse_date_todatetime_struct(did_parsed) > age60_dt:
                        paiend_candidate_list.append((dh.parse_datetime_to_ifs_date(age60_dt), '0'))
                    else:
                        paiend_candidate_list.append((did_parsed, '0'))
                else:
                    if subd['FNL_DSPN_DT'] not in ['U', 'E']:
                        if dh.parse_date_todatetime_struct(subd['FNL_DSPN_DT']) > age60_dt:
                            paiend_candidate_list.append((dh.parse_datetime_to_ifs_date(age60_dt), '1'))
                        else:
                            paiend_candidate_list.append((subd['FNL_DSPN_DT'], '1'))
                    else:
                        paiend_candidate_list.append(('E', 'E'))

            else:
                if did_parsed != 'U':
                    paiend_candidate_list.append((did_parsed, '0'))
                else:
                    if subd['FNL_DSPN_DT'] not in ['U', 'E']:
                        paiend_candidate_list.append((subd['FNL_DSPN_DT'], '1'))
                    else:
                        paiend_candidate_list.append(('E', 'E'))

        # If any 'E' values in paiend_candidate_list, then logically cannot be sure of
        # paiend or struct_agerel_paiend; output 'E':
        if 'E' in [tup[0] for tup in paiend_candidate_list]:
            return 'E', 'E', 'E'

        # Convert paiend_candidate_list date entries into DT objects:
        paiend_candidate_list_dt = [(dh.parse_date_todatetime_struct(d[0]), d[1]) for d in paiend_candidate_list]

        # If no paiend_candidate_list_dt or a conversion failed ('E'), then
        # cannot be certain of PAI end; return 'E' values:
        if not paiend_candidate_list_dt or 'E' in [tup[0] for tup in paiend_candidate_list_dt]:
            return 'E', 'E', 'E'

        # Find latest PAI end date across claims:
        paiend_candidate_list_max_tup = max(paiend_candidate_list_dt, key=itemgetter(0))

        # Calculate age from that latest point:
        struct_agerel_paiend = dh.calc_age(structdob_dt, paiend_candidate_list_max_tup[0])

        # Return struct_agerel_paiend and paiend:
        return struct_agerel_paiend, paiend_candidate_list_max_tup[1], dh.parse_datetime_to_ifs_date(
            paiend_candidate_list_max_tup[0])

    except Exception:
        logger.exception('EXCEPTION')
        return 'E', 'E0', 'E'


# Calculate 'STRUCT_AGE_DID':
# DEPRECATION WARNING (06282017): Not as useful
# as STRUCT_AGE_PAIEND and thus will not be
# output.
def calc_struct_agerel_did(input_dict):
    '''Calculate the claimant's age as of the
    disposition date for a given claim entity
    (e.g. its ARCHWKUT.FNL_DSPN_DT value) from
    the claimant's date of birth (e.g. ARCHWKUT.CLMT_DOB).

    Args:
        input_dict {dict}: An INSIGHT observation
            dictionary.
    Returns:
        The claimant's age at the disposition date {str}.
    Raises:
        N/A (returns 'E' if exception occurs).
    '''
    try:
        clmt_dob = input_dict['CLMT_DOB']
        fnl_dspn_dt = input_dict['FNL_DSPN_DT']
        if clmt_dob not in ['U', 'E'] and fnl_dspn_dt not in ['U', 'E']:
            return dh.calc_age(clmt_dob, fnl_dspn_dt)
        else:
            return 'E'
    except Exception:
        logger.exception('EXCEPTION')
        return 'E'
