# INSIGHT DATE HELPER
#
# AUTHOR:
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 09.09.2016
#
# SUMMARY:
# This module consists of a suite of tools designed to extract, normalize,
# and otherwise parse date strings and datetime objects.
#
# DATE PARSING NOTES:
#
# # Tried 'dateparser' - essentially same performance as in-house:
# >>> dateparser.parse("June 2010")
# datetime.datetime(2010, 6, 27, 0, 0)
# >>> dh.parse_date_todatetime_struct("June 2010")
# datetime.datetime(2010, 6, 26, 0, 0)
# >>> dateparser.parse("He was born in June 2010")
# >>> dh.parse_date_todatetime_struct("He was born in June 2010")
# 'E'
# >>> dateparser.parse("June of 2010")
# datetime.datetime(2010, 6, 27, 0, 0)
# >>> dh.parse_date_todatetime_struct("June of 2010")
# datetime.datetime(2010, 6, 26, 0, 0)

# # Tried 'semantic' - terrible, glitchy performance:
# >>> date = service.extractDate("On March 3, 2010")
# >>> date
# datetime.datetime(2017, 3, 3, 21, 55)

# Tried 'datefinder' - while it proclaims to be able
# to extract dates from free text, and while it *does*
# do so in some circumstances, particularly for date
# ranges as needed by INSIGHT it falls short:
# >>> x = datefinder.find_dates("from June 4, 2010 through August 5, 2016")
# >>> for res in x:
# ...     print res
# ...
# 2010-06-04 00:00:00
# 2016-08-05 00:00:00
# >>> x = datefinder.find_dates("from June 4, 2010 to August 5, 2016")
# >>> for res in x:
# ...     print res
# ...
# >>>
#
# WARNING:
# The following is alpha-level/prototype software whose output quality has
# not yet been formally validated and whose documentation is not yet fully
# formed.
# =============================================================================

# Import modules:
import datetime
import logging
import os.path
import re

from dateutil import parser
from dateutil.relativedelta import relativedelta

# Set data directory:
insightdir = os.path.dirname(os.path.realpath(__file__))
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


# Parse a 'fully written' date string to return a tuple of
# normalized day, month, and year results (each item = either '[?]'
# or a two digit number):
def parse_date(date_string):
    month_num_dict = {'january':1, 'february':2, 'march':3, 'april':4, 'may':5,
                      'june':6, 'july':7, 'august':8, 'september':9, 'october':10,
                      'november':11, 'december':12, 'jan':1, 'feb':2, 'mar':3, 'apr':4,
                      'jun':6, 'jul':7, 'aug':8, 'sept':9, 'oct':10, 'nov':11, 'dec':12}

    try:
        # If an already-parsed date, process that:
        if bool(re.search(r"^([0-9]{2}|\[\?\])/([0-9]{2}|\[\?\])/([0-9]{4}|\[\?\])$", date_string)):

            date_convert_day_unstructured = '[?]'
            date_convert_day_unstructured_search = re.search(r"(?:/)([0-9]{2})(?:/)", date_string)
            if bool(date_convert_day_unstructured_search):
                date_convert_day_unstructured = date_convert_day_unstructured_search.group(1)

            date_convert_month_unstructured = '[?]'
            date_convert_month_unstructured_search = re.search(r"^[0-9]{2}", date_string)
            if bool(date_convert_month_unstructured_search):
                date_convert_month_unstructured = date_convert_month_unstructured_search.group()

            date_convert_year_unstructured = '[?]'
            date_convert_year_unstructured_search = re.search(r"[0-9]{4}$", date_string)
            if bool(date_convert_year_unstructured_search):
                date_convert_year_unstructured = date_convert_year_unstructured_search.group()

            return (date_convert_day_unstructured, date_convert_month_unstructured, date_convert_year_unstructured)

        # If NOT an already-parsed date (i.e. a fully written date), process that:
        else:

            # Normalize date string:
            date_normalized = date_string.lower()
            date_normalized = " ".join(date_normalized.split())

            # Search/parse day of month:
            date_day_verifier_unstructured1 = re.search(r'(\d{1,2}), ?(?:\d {,2}){3}\d', date_normalized)
            date_day_verifier_unstructured2 = re.search(
                r'(january|february|march|april|may|june|july|august|september|october|november|december|\bjan\.?|\bfeb\.?|\bmar\.?|\bapr\.?|\bmay\.?|\bjun\.?|\bjul\.?|\baug\.?|\bsept\.?|\boct\.?|\bnov\.?|\bdec\.?) ?(\d{1,2})(,| )',
                date_string)
            date_day_verifier_unstructured = None
            if bool(date_day_verifier_unstructured1):
                date_day_verifier_unstructured = date_day_verifier_unstructured1
            elif bool(date_day_verifier_unstructured2):
                date_day_verifier_unstructured = date_day_verifier_unstructured2

            if bool(date_day_verifier_unstructured):
                date_convert_day_unstructured = date_day_verifier_unstructured.group(1)
                date_convert_day_unstructured = date_convert_day_unstructured.strip()
                # TIP: Adding leading zero:
                if len(date_convert_day_unstructured) == 1:
                    date_convert_day_unstructured = '0' + date_convert_day_unstructured
            else:
                date_convert_day_unstructured = '[?]'

            # Search/parse month:
            date_month_verifier_prep = re.sub(r'[^a-z]', '',
                                              date_normalized)  # [^a-z] selects all non-alphabetic chars.
            date_month_verifier_unstructured = re.search(
                r"(^|[^a-zA-Z])(january)($|[^a-zA-Z])|(^|[^a-zA-Z])(february)($|[^a-zA-Z])|(^|[^a-zA-Z])(march)($|[^a-zA-Z])|(^|[^a-zA-Z])(april)($|[^a-zA-Z])|(^|[^a-zA-Z])(may)($|[^a-zA-Z])|(^|[^a-zA-Z])(june)($|[^a-zA-Z])|(^|[^a-zA-Z])(july)($|[^a-zA-Z])|(^|[^a-zA-Z])(august)($|[^a-zA-Z])|(^|[^a-zA-Z])(september)($|[^a-zA-Z])|(^|[^a-zA-Z])(october)($|[^a-zA-Z])|(^|[^a-zA-Z])(november)($|[^a-zA-Z])|(^|[^a-zA-Z])(december)($|[^a-zA-Z])|(^|[^a-zA-Z])(jan)($|[^a-zA-Z])|(^|[^a-zA-Z])(feb)($|[^a-zA-Z])|(^|[^a-zA-Z])(mar)($|[^a-zA-Z])|(^|[^a-zA-Z])(apr)($|[^a-zA-Z])|(^|[^a-zA-Z])(may)($|[^a-zA-Z])|(^|[^a-zA-Z])(jun)($|[^a-zA-Z])|(^|[^a-zA-Z])(jul)($|[^a-zA-Z])|(^|[^a-zA-Z])(aug)($|[^a-zA-Z])|(^|[^a-zA-Z])(sept)($|[^a-zA-Z])|(^|[^a-zA-Z])(oct)($|[^a-zA-Z])|(^|[^a-zA-Z])(nov)($|[^a-zA-Z])|(^|[^a-zA-Z])(dec)($|[^a-zA-Z])",
                date_month_verifier_prep, re.I)
            if bool(date_month_verifier_unstructured):
                date_convert_month_unstructured = date_month_verifier_unstructured.group()
                date_convert_month_unstructured = str(month_num_dict[date_convert_month_unstructured])
                # TIP: Adding leading zero:
                if len(date_convert_month_unstructured) == 1:
                    date_convert_month_unstructured = '0' + date_convert_month_unstructured
            else:
                date_convert_month_unstructured = '[?]'

            # Search/parse year:
            # date_year_verifier_unstructured = re.search(r'(?:\d {,2}){3}\d', date_normalized)
            date_year_verifier_unstructured = re.search(r'(^|[^0-9])(\d ?\d ?\d ?\d ?)($|[^0-9])', date_normalized)

            if bool(date_year_verifier_unstructured):
                date_convert_year_unstructured = date_year_verifier_unstructured.group(2)
                date_convert_year_unstructured = re.sub(' ?', '', date_convert_year_unstructured)
                date_convert_year_unstructured = date_convert_year_unstructured.strip()
            else:
                date_convert_year_unstructured = '[?]'

            return (date_convert_day_unstructured, date_convert_month_unstructured, date_convert_year_unstructured)
    except Exception:
        logger.critical(date_string)
        logger.exception('EXCEPTION')
        return 'E'


# Convert a fully written date string into an INSIGHT formatted date string:
def parse_date_tostr(date_string):
    '''Convert a fully written date string (e.g. 'January 21, 2010') into an
    INSIGHT formatted date string (e.g. '01/21/2010').  Value over
    use of dateutil.parser is that this missing values are not rotely
    replaced; rather, the parser attempts to identify missing values
    and document their absence via '[?]' entries while also outputting
    a bracketed copy of the original, e.g. "January 230, 2010"
    returns "01/[?]/2010 [Original: 'January 230, 2010']").

    Args:
        date_string {str}: A fully written date.
    Returns:
        An INSIGHT-formatted date.
    Raises:
        N/A (logs/raises exception).
    '''
    try:
        # TIP: To prevent looping output error for already INSIGHT-formatted dates,
        # remove any 'Original' INSIGHT-formatted data that may be present:
        date_normalized = re.sub(r" \[Original.*", "", date_string)

        date_parsed = parse_date(date_normalized)

        if len([el for el in date_parsed if el == '[?]']) == 3:
            return 'E'
        else:
            formatted_date = '/'.join([date_parsed[1], date_parsed[0], date_parsed[2]])
            if '[?]' in formatted_date:
                return formatted_date + ' [Original: ' + date_normalized + ']'
            return formatted_date
    except Exception:
        logger.critical(date_string)
        logger.exception('EXCEPTION')
        return 'E'


# Convert an unpredictable date string to a datetime object:
def parse_date_todatetime_struct(date_string):
    """Parses variety of fairly standard formats of dates in strings
    using the functionality in dateutil.parser to output a datetime
    object.  Used by calc_age().

    WARNING: Missing values will be filled in with the present date's
    corresponding value. Thus, to prevent data loss, only pass reliably
    complete dates to this function, or date details could be modified.
    Examples:
    parse("December") -> datetime.datetime(2016, 12, 18, 0, 0)
    parse("2016") -> datetime.datetime(2016, 12, 18, 0, 0)
    parse('Jan2010') -> datetime.datetime(2016, 1, 18, 0, 0)

    NOTE: dateutil will NOT parse if a day of the
    month and year are present but a month is not present.  It WILL
    parse only a month and year, only a month and day of the month,
    or only a year.

    Input {str}:
        String containing a date.
    Output {datetime object}:
        A datetime object.
        'E' - function was unable to output a datetime object (e.g.
        an exception occurred).
    Raises:
        N/A.
    """
    try:
        # If already datetime object, return input value:
        if isinstance(date_string, datetime.datetime):
            return date_string

        # If datetime.date, convert to datetime.datetime and return value:
        if isinstance(date_string, datetime.date):
            date_dt = datetime.datetime.combine(date_string, datetime.datetime.min.time())
            return date_dt

        # Confirm type:
        if bool(isinstance(date_string, str)) is False:
            return 'E'
        else:
            # Normalize date string and add spaces between strings and letters
            # (increases parser accuracy in face of dates like '08AUG2016'):
            date_string = date_string.strip().lower()
            date_string = re.sub(r"([a-z])([0-9])", r"\1 \2", date_string)
            date_string = re.sub(r"([0-9])([a-z])", r"\1 \2", date_string)
            date_string = date_string.replace(":00:00:00.000", "")

            # Parse date string using dateutil parser:
            # TIP: dateutil's parser returns a ValueError where it receives
            # an unknown string format (i.e. it can't parse it).
            try:
                parsed_datetime_obj = parser.parse(date_string)
                return parsed_datetime_obj
            except ValueError:
                return 'E'
    except Exception:
        logger.critical(date_string)
        logger.exception('EXCEPTION')
        return 'E'


# Convert datetime.datetime or datetime.date object to INSIGHT-formatted date string:
def parse_datetime_to_ifs_date(datetime_obj):
    """Convert a datetime object into an INSIGHT-formatted
    date string (i.e. '##/##/####' or 'MM/DD/YYYY' with a leading
    zero included.

    Input {str}:
        datetime_obj {datetime object}
    Output {datetime object}:
        A string containing an INSIGHT-formatted date.
        'E' - function was unable to output a date string (e.g.
        an exception occurred).
    Raises:
        N/A.
    """
    try:
        if bool(isinstance(datetime_obj, datetime.datetime)) is False and bool(
                isinstance(datetime_obj, datetime.date)) is False:
            if not isinstance(datetime_obj, str):
                return 'E'
            else:
                if not datetime_obj:
                    return 'E'
                datetime_obj = parse_date_todatetime_struct(datetime_obj)
                if not isinstance(datetime_obj, datetime.datetime):
                    return 'E'

        ifs_date_str = datetime_obj.strftime('%m/%d/%Y')
        return ifs_date_str
    except Exception:
        logger.critical(str(datetime_obj))
        logger.exception('EXCEPTION')
        return 'E'


# Age calculator:
def calc_age(earlier_date_input, later_date_input):
    '''Calculate age using two predictible or
    unpredictable date strings OR datetime objects.

    Args:
        earlier_date_input {str , datetime.datetime, or datetime.date
            object}: The earlier date to utilize for age calculation
            (typically date of birth)
        earlier_date_input {str , datetime.datetime, or datetime.date
            object}: The later date to utilize for age calculation.
    Returns:
        An age string formatted as '#-y-#-mo';

    Raises:
        N/A (will return 'E' if an exception occurs
            or the calculation could otherwise not be
            performed)
    '''
    try:
        # Attempt to normalize inputs to datetime objects:
        if isinstance(earlier_date_input, datetime.datetime) or isinstance(earlier_date_input, datetime.date):
            earlier_datetime_obj = earlier_date_input
        else:
            earlier_datetime_obj = parse_date_todatetime_struct(earlier_date_input)
        if isinstance(later_date_input, datetime.datetime) or isinstance(later_date_input, datetime.date):
            later_datetime_obj = later_date_input
        else:
            later_datetime_obj = parse_date_todatetime_struct(later_date_input)
        # Calculate age using dateutil.relativedelta, then convert the
        # relativedelta object to a string:
        if (isinstance(earlier_datetime_obj, datetime.datetime) or
                isinstance(earlier_datetime_obj, datetime.date)) and \
                (isinstance(later_datetime_obj, datetime.datetime) or isinstance(later_datetime_obj, datetime.date)):
            reldelta = relativedelta(later_datetime_obj, earlier_datetime_obj)
            yearint = reldelta.years
            monthint = reldelta.months
            # TIP: If somehow a negative year/month value, suggestive of an error in the
            # structured data; return 'E'.
            if yearint >= 0 and monthint >= 0:
                yearstr = str(yearint)
                monthstr = str(monthint)
                agestr = '%s-y-%s-m' % (yearstr, monthstr)
                return agestr
            else:
                return 'E'
        else:
            return 'E'
    except Exception:
        try:
            logger.critical(earlier_date_input)
            logger.critical(type(earlier_date_input))
            logger.critical(later_date_input)
            logger.critical(type(later_date_input))
        except Exception:
            pass
        logger.exception('EXCEPTION')
        return 'E'


def calc_age_reldelta(earlier_date_input, later_date_input):
    '''Calculate age using two predictible or
    unpredictable date strings OR datetime objects to
    return the difference/age between the two dates and (if applicable)
    the age category corresponding to that age.

    Args:
        earlier_date_input {str , datetime.datetime, or datetime.date
            object}: The earlier date to utilize for age calculation
            (typically date of birth)
        earlier_date_input {str , datetime.datetime, or datetime.date
            object}: The later date to utilize for age calculation.
    Returns:
        A tuple where:
            tuple[0] = a success/error 'verdict' value
            ('1' for success, 'E' [plus a numeric indicating error type]
            for error);
            tuple[1] = a dateutil.relativedelta object
            containing the difference between the two dates (if error
            precludes relativedelta calculation, an 'E' value will be
            output at tuple[1]);
            tuple[2] = an age category abbreviation where:
                'YI
    Raises:
        N/A (will log error and return error-indicating tuple
        as outlined above).
    '''
    try:
        # Attempt to normalize inputs to datetime objects:
        if isinstance(earlier_date_input, datetime.datetime) or isinstance(earlier_date_input, datetime.date):
            earlier_datetime_obj = earlier_date_input
        else:
            earlier_datetime_obj = parse_date_todatetime_struct(earlier_date_input)
        if isinstance(later_date_input, datetime.datetime) or isinstance(later_date_input, datetime.date):
            later_datetime_obj = later_date_input
        else:
            later_datetime_obj = parse_date_todatetime_struct(later_date_input)
        # Calculate age using dateutil.relativedelta:
        if not (isinstance(earlier_datetime_obj, datetime.datetime) or
                isinstance(earlier_datetime_obj, datetime.date)) or not \
                (isinstance(later_datetime_obj, datetime.datetime) or
                 isinstance(later_datetime_obj, datetime.date)):
            return ('E1', 'E')
        else:
            reldelta = relativedelta(later_datetime_obj, earlier_datetime_obj)
            # TIP: If somehow a negative year value, suggestive of an error in the
            # structured data; return 'E'.
            yearint = reldelta.years
            if yearint >= 0:
                return ('1', reldelta)
            else:
                return ('E2', reldelta)
    except Exception:
        try:
            logger.critical(earlier_date_input)
            logger.critical(type(earlier_date_input))
            logger.critical(later_date_input)
            logger.critical(type(later_date_input))
        except Exception:
            pass
        logger.exception('EXCEPTION')
        return ('E0', 'E')
