# INSIGHT FULL SUITE - INSIGHT DATABASE SETUP ACTIONS
#
# AUTHOR:
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 06.29.2017
#
# SUMMARY:
# Contains scripts designed to help 'set up' an instance of the
# INSIGHT database, such as populating reference table data.
#
# WARNING:
# The following is alpha-level/prototype software whose output quality has
# not yet been formally validated and whose documentation is not yet fully
# formed.
# =============================================================================

# Import modules:
import os
import os.path
import sys
import urllib

import pandas
from sqlalchemy import create_engine, MetaData

import config as cfg

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
datadir = os.path.join(insightdir, "Data")


# Define function to INSERT and/or UPDATE static data into INSIGHT DB:
def push_static_data(static_data_fn):
    '''Push INSIGHT static data housed in the 'data' directory
    to a corresponding INSIGHT DB table.

    NOTE: Designed to work where the static file base name matches the
    name of the target INSIGHT DB table.

    WARNING: As configured, any time the corresponding INSIGHT
    DB table exists already, this will truncate that table and
    then insert the data.  This is done to maintain the schema
    data types, which otherwise would be replaced if 'if_exists'
    were not set to 'append'.

    Args:
        static_data_fn {str}: The file name of the static data
            file whose contents you wish to push to its
            corresponding INSIGHT DB table.
    Returns:
        N/A.
    Raises:
        All exceptions will be raised.
    '''
    try:

        # Get file name without extension to use as target table name:
        static_fn_noext = os.path.splitext(static_data_fn)[0]

        # Load static file into DataFrame:
        static_df = pandas.read_csv(os.path.join(datadir, static_data_fn), dtype=str, encoding='utf-8')

        # Create INSIGHT DB connection string,
        # then connect via sqlalchemy:
        db_cnxn_str = "%s:%s@%s:%s/%s" % (cfg.postgres_username, cfg.postgres_password, cfg.postgres_hostname, cfg.postgres_port, cfg.postgres_dbname)
        engine = create_engine("postgresql+psycopg2://" + db_cnxn_str)
        conn = engine.connect()
        metadata = MetaData(conn)

        # Write DataFrame contents to target table:
        static_df.to_sql(static_fn_noext, engine, schema='appeals', if_exists="append", index=False)

        # Close connection:
        conn.close()

    except Exception:
        try:
            conn.close()
        except Exception:
            pass
        raise


if __name__ == '__main__':
    print push_static_data('mvrtable.csv')
