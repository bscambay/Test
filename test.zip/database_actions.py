# INSIGHT DATABASE ACTIONS
#
# AUTHOR:
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# SUMMARY:
# Contains functions to perform common database actions required by
# INSIGHT, such as adding/updating table rows or retrieving table row
# data.
#
# DATE LAST UPDATED:
# 10.25.2016
#
# UPDATES/NOTES:
# 10.25.2016:
# - Worked with DCS to ensure remote access to NLPDEV;
# - Updated record existence SQL to faster method per http://stackoverflow.com/questions/30342758/fastest-way-to-check-the-records-if-exists-in-the-sql-table
#
# WARNING:
# The following is alpha-level/prototype software whose output quality has
# not yet been formally validated and whose documentation is not yet fully
# formed.
# ==============================================================================

import logging
import math
import os.path
import sys

import pandas
import psycopg2
from psycopg2 import sql
from sqlalchemy import create_engine, MetaData, text

import common_fx as cfx
import config as cfg

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
inputdir = os.path.join(insightdir, "Input/Input")
processingdir = os.path.join(insightdir, "Input/Processing")
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


# Retrieve entire contents of table:
def retrieve_all_ifs_tbl(tbl_nm):
    db_cnxn_str = "%s:%s@%s:%s/%s" % (cfg.postgres_username, cfg.postgres_password, cfg.postgres_hostname, cfg.postgres_port, cfg.postgres_dbname)
    engine = create_engine("postgresql+psycopg2://" + db_cnxn_str)
    conn = engine.connect()
    sql_str = text("SELECT * FROM " + tbl_nm)
    df = pandas.read_sql(sql_str, conn)
    conn.close()
    return df


# Retrieve all instances of a given column from a given table (schema 2):
def retrieve_column_values(tbl_nm_str, column_nm_str):
    '''Retrieves all values for a target column
    name housed in a target IFS database table.

    Args:
        tbl_nm_str {str}: Name of the table to query
            (within IFS database).
        column_nm_str {str}: Name of the column whose
            values are to be retrieved.
    Returns:
        A Python list containing all values associated
            with the target column name; if no values
            returns empty list.
    Raises:
        N/A (if exception, returns empty list).'''
    try:
        conn_str = "host='%s' port='%s' dbname='%s' user='%s' password='%s'" % (cfg.postgres_hostname, cfg.postgres_port, cfg.postgres_dbname, cfg.postgres_username, cfg.postgres_password)
        tbl_name = tbl_nm_str.replace('appeals.', '')

        sql_str = """
            SELECT table_name
            FROM information_schema.tables
            where table_type = 'BASE TABLE'
            and table_schema = 'appeals'
            and table_name = %s """
        with psycopg2.connect(conn_str) as connection:
            with connection.cursor() as cur:
                cur.execute(sql_str, (tbl_name, ) )
                tbl_tuple = cur.fetchone()[0]

                if tbl_nm_str.replace('appeals.', '') not in tbl_tuple:
                    err_str = "database_actions.retrieve_column_values(%s, %s) - tbl_nm_str not in INSIGHT Table list" % (
                        tbl_nm_str, column_nm_str)
                    logger.critical(err_str)
                    return []
                else:
                    cur.execute(sql.SQL('select {} from "appeals".{}').format(sql.SQL(', ').join(sql.Identifier(n) for n in column_nm_str.split(',') ), sql.Identifier(tbl_nm_str) ))
                    reslist = cur.fetchall()
                    reslist = [r[0] for r in reslist]
                    return reslist
    except Exception as e:
        logger.exception('Exception')
        return []


# Retrieve all instances of a given column from a given table where
# its REQID value = X (schema 2):
def retrieve_select_schema2(reqid, tbl_nm, col_nm):
    conn_str = "host='%s' port='%s' dbname='%s' user='%s' password='%s'" % (cfg.postgres_hostname, cfg.postgres_port, cfg.postgres_dbname, cfg.postgres_username, cfg.postgres_password)
    try:
        # Connect to INSIGHT database:
        with psycopg2.connect(conn_str) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT %s FROM %s WHERE REQID = %s", (col_nm, tbl_nm, reqid))
                res = cur.fetchall()
                if not res:
                    return []
                else:
                    res = list(cfx.flatten_irreg(res))
                    return res

    except Exception:
        logger.exception('EXCEPTION')
        err_str = 'REQID PASSED = %s' % str(reqid)
        logger.critical(err_str)
        return []


# Iterate through table names to retrieve its colum INSIGHT data point names (column names) present in that table:
def retrieve_case_entity_schema2(reqid):
    '''Retrieves a case entity's data from the
    INSIGHT OAO database (schema 2) using the
    REQID value associated with that case entity.

    Args:
        reqid {str}: An INSIGHT 'REQID' value.
    Returns:
        resdict {dict}: A dict where each key
            is either a column name from the
            'dspn_doc' parent table or the name
            of a child table (e.g. 'struct_hodisp').

            Each 'dspn_doc' column name key's value
            will be the value associated with that
            column name (e.g. a value of '1' for the
            column name key 'verefbg').
            Each child table key's value will be a
            list containing a dictionary for each
            observation associated with that REQID
            in that child table. If none, the list
            will be empty.

            If no observations are found in 'dspn_doc'
            for the REQID value passed, the dictionary
            will be empty.
    Raises:
        N/A (if exception occurs, an empty dictionary is
        returned).
    '''
    def change2_upper(tbl_name, col_name_l):
        upper_list = cfg.ifs_db_uppercase_columns[tbl_name]
        return [name.upper() if name in upper_list else name for name in col_name_l]

    # try:
    reqid_dict = {}

    # Connect to INSIGHT database:
    conn_str = "host='%s' port='%s' dbname='%s' user='%s' password='%s'" % (cfg.postgres_hostname, cfg.postgres_port, cfg.postgres_dbname, cfg.postgres_username, cfg.postgres_password)
    conn = psycopg2.connect(conn_str)
    cur = conn.cursor()
    sql = "SELECT * FROM appeals.dspn_doc WHERE reqid = %s"
    tbl_name = 'appeals.dspn_doc'
    # col_names = [row[3] for row in cursor_SQLNLP.columns(table=cfg.ifs_database_tblnm_list_s2_nonstruct_parent)]
    cur.execute(sql, (reqid,))
    col_names = [desc[0] for desc in cur.description]
    col_names = change2_upper(tbl_name, col_names)
    res = cur.fetchone()

    if not res:
        return {}
    else:
        par_resdict = dict(zip(col_names, res))
        for k, v in par_resdict.iteritems():
            if v is None or (isinstance(v, float) and math.isnan(v)) or v == '':
                reqid_dict[k] = 'U'
            else:
                reqid_dict[k] = v

    # Add child table values:
    for tbl_nm in cfg.ifs_database_tblnm_list_s2_nonstruct_child:
        try:
            sql = "SELECT * FROM %s WHERE REQID = %s" % (tbl_nm, reqid)
            cur.execute(sql)
            col_names = [desc[0] for desc in cur.description]
            col_names = change2_upper(tbl_nm, col_names)
            res = cur.fetchall()
            if not res:
                reqid_dict[tbl_nm.replace('appeals.', '')] = []
            else:
                chd_reqid_dictlist = []
                chd_resdictlist = [dict(zip(col_names, indivres)) for indivres in res]
                for chd_dict in chd_resdictlist:
                    chd_dict_cleaned = {}
                    for k, v in chd_dict.iteritems():
                        if v is None or (isinstance(v, float) and math.isnan(v)) or v == '':
                            chd_dict_cleaned[k] = 'U'
                        else:
                            chd_dict_cleaned[k] = v
                    chd_reqid_dictlist.append(chd_dict_cleaned)
                reqid_dict[tbl_nm.replace('appeals.', '')] = chd_reqid_dictlist
        except Exception as e:
            logger.exception('EXCEPTION')
            logger.critical(tbl_nm)
            logger.critical(reqid)
            logger.debug(str(e))
            #res_dict[tbl_nm] = []

    # Add struct table values:
    for tbl_nm in cfg.ifs_database_tblnm_list_s2_struct:
        try:
            sql = "SELECT * FROM %s WHERE reqid = %s" % (tbl_nm, reqid)
            cur.execute(sql)
            col_names = [desc[0] for desc in cur.description]
            col_names = change2_upper(tbl_nm, col_names)
            res = cur.fetchall()
            if not res:
                reqid_dict[tbl_nm.replace('appeals.', '')] = []
            else:
                chd_reqid_dictlist = []
                chd_resdictlist = [dict(zip(col_names, indivres)) for indivres in res]
                for chd_dict in chd_resdictlist:
                    chd_dict_cleaned = {}
                    for k, v in chd_dict.iteritems():
                        if v is None or (isinstance(v, float) and math.isnan(v)) or v == '':
                            chd_dict_cleaned[k] = 'U'
                        else:
                            chd_dict_cleaned[k] = v
                    chd_reqid_dictlist.append(chd_dict_cleaned)
                reqid_dict[tbl_nm.replace('appeals.', '')] = chd_reqid_dictlist
        except Exception:
            logger.exception('EXCEPTION')
            logger.critical(tbl_nm)
            logger.critical(reqid)
            #res_dict[tbl_nm] = []

    # Close database connections:
    cur.close()
    del cur
    conn.close()

    return reqid_dict

    # except Exception as e:
    #     logger.exception('EXCEPTION')
    #     err_str = 'REQID PASSED = %s' % str(reqid) + ' ' + str(e)
    #     logger.critical(err_str)
    #     return {}


# Retrieve a specific case entity data:
def retrieve_case_entity(uid_nm, uid_val):
    '''Retrieves a case entity's data from the
    INSIGHT OAO database (schema 2) using the
    a passed UID value.

    Args:
        uid_nm {str}: Unique identifer (UID) name, equal
            to an INSIGHT database column name for a common
            UID in the 'dspn_doc', 'struct_hodisp', or
            'struct_oao' table.  Acceptable values are
            'HOFC_WRK_UNIT_UID', 'EFLDR_NUM', 'hofc_wrk_unit_AC',
            or 'DOCU_CTL_ID'.
        uid_val {str}: The 'uid_nm' value associated
            with the case entity whose data is targeted
            for retrieval.
    Returns:
        resdict {dict}: A dict where each key
            is either a column name from the
            'dspn_doc' parent table or the name
            of a child table (e.g. 'struct_hodisp').

            Each 'dspn_doc' column name key's value
            will be the value associated with that
            column name (e.g. a value of '1' for the
            column name key 'verefbg').
            Each child table key's value will be a
            list containing a dictionary for each
            observation associated with that REQID
            in that child table. If none, the list
            will be empty.

            If no observations are found in 'dspn_doc'
            for the REQID value passed, the dictionary
            will be empty.
    Raises:
        N/A (if exception occurs, an empty dictionary is
        returned).
    '''
    try:
    # Parse arguments:
        if uid_nm.upper() == 'REQID':
            reqid_dict = retrieve_case_entity_schema2(uid_val)
            return reqid_dict
        else:
            # Retrieve REQID:
            # TIP: Should only be one REQID for any of these
            # values *except* for CLMT_SSN.  If that's passed, only
            # the first case entity associated with that will be returned
            # for now.
            conn_str = "host='%s' port='%s' dbname='%s' user='%s' password='%s'" % (cfg.postgres_hostname, cfg.postgres_port, cfg.postgres_dbname, cfg.postgres_username, cfg.postgres_password)
            reqid = 'U'
            with psycopg2.connect(conn_str) as conn:
                with conn.cursor() as cur:
                    if uid_nm in ['hofc_wrk_unit_uid', 'efldr_num', 'clmt_ssn']:
                        cur.execute(sql.SQL('select reqid from appeals.struct_hodisp where {} = %s').format(sql.Identifier(uid_nm)), [uid_val])
                        res = cur.fetchone()
                        if res:
                            reqid = res[0]
                    elif uid_nm == 'hofc_wrk_unit_ac':
                        cur.execute(sql.SQL('SELECT REQID FROM appeals.struct_oao WHERE {} = %s').format(sql.Identifier(uid_nm)), [uid_val])
                        res = cur.fetchone()
                        if res:
                            reqid = res[0]
                    else:
                        cur.execute(sql.SQL('SELECT REQID FROM appeals.dspn_doc where {} = %s').format(sql.Identifier(uid_nm)), [uid_val])
                        res = cur.fetchone()
                        if res:
                            reqid = res[0]

                    if reqid == 'U':
                        return {}
                    else:
                        reqid_dict = retrieve_case_entity_schema2(reqid)
                        return reqid_dict
    except Exception:
        logger.exception('EXCEPTION')
        logger.critical(uid_nm)
        logger.critical(uid_val)
        return {}

# if __name__ == '__main__':
    # print retrieve_all_ifs_tbl('appeals.usagelog')
    # print retrieve_column_values('usagelog', 'reqid')
    # print retrieve_case_entity('hofc_wrk_unit_uid', 11192688)
    # print retrieve_case_entity('hofc_wrk_unit_ac', 8209445)
    # print retrieve_case_entity('docu_ctl_id', 'A1001001A17E25A73853A81513')
    # print retrieve_select_schema2(2, 'appeals.s2', 's2txt')
    # print retrieve_case_entity_schema2(4)
