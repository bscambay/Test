# INSIGHT FULL SUITE MASTER CONFIGURATION FILE
#
# SUMMARY:
# Contains configuration data.  For security reasons, this will NOT be
# distributed externally to INSIGHT version control.
#
# =============================================================================

# Import modules:
import datetime
from util import get_value_from_env, is_insight_env_loaded, load_insight_env, get_raw_value_from_env

# Load all settings and configurations from the environment.
#
# First check if environment variables are loaded.
# If they are loaded then move on. Else assume we are in dev and load those credentials

if not is_insight_env_loaded():
    load_insight_env()

# Set parameter values for bottle_oao.py Bottle 'run()' call:
bottle_run_hn = get_value_from_env('INSIGHT_BOTTLE_RUN_HN')
bottle_run_port = get_value_from_env('INSIGHT_BOTTLE_RUN_PORT')

# IFS Database Table Names for Postgres:
ifs_database_tblnm_list_s2_struct = ['appeals.struct_hodisp', 'appeals.struct_oao', 'appeals.struct_exp']
ifs_database_tblnm_list_s2_nonstruct_parent = 'dspn_doc'
ifs_database_tblnm_list_s2_nonstruct_child = ['appeals.claimdisp', 'appeals.quality', 'appeals.s1sga', 'appeals.s2', 'appeals.mdi', 'appeals.s3mteq', 'appeals.s3feq', 'appeals.rfc', 'appeals.s4', 'appeals.s4dot', 'appeals.s5', 'appeals.s5dot', 'appeals.mvr', 'appeals.srcnm']
ifs_db_uppercase_columns = {
    'appeals.dspn_doc': ['reqid', 'docu_ctl_id', 'struct_agerel_paistart', 'struct_agerel_paistart_src', 'struct_agerel_paiend', 'struct_agerel_paiend_src', 'struct_age_did', 'circuit_struct'],
    'appeals.claimdisp': ['reqid','docu_ctl_id'],
    'appeals.quality': ['reqid','ord_num1','ord_num2'],
    'appeals.s1sga': ['reqid','ord_num'],
    'appeals.s2': ['reqid','ord_num'],
    'appeals.mdi': ['reqid','s2_ord_num','cui','txt','typ'],
    'appeals.s3mteq': ['reqid','ord_num'],
    'appeals.s3feq': ['reqid','ord_num'],
    'appeals.rfc': ['reqid','ord_num'],
    'appeals.s4': ['reqid','ord_num'],
    'appeals.s4dot': ['reqid','s4_ord_num'],
    'appeals.s5': ['reqid','ord_num'],
    'appeals.s5dot': ['reqid','s5_ord_num'],
    'appeals.mvr': ['reqid','s5_ord_num'],
    'appeals.srcnm': ['reqid','ord_num'],
    'appeals.struct_hodisp': ['reqid', 'hofc_wrk_unit_uid', 'clmt_ssn', 'efldr_num', 'fnl_dspn_dt', 't2_dspn_cd', 't16_dspn_cd', 't2_prtl_ffvrbl_cd', 't16_prtl_ffvrbl_cd', 't2_glbl_bss_uid_1', 't2_glbl_bss_uid_2', 't16_glbl_bss_uid_1', 't16_glbl_bss_uid_2', 'clmt_nm25', 'clm_typ', 'clm_uid', 'case_grp_cd', 't2_app_dt', 't16_app_dt', 't2_pflg_dt', 't16_pflg_dt', 'clmt_st', 'clmt_dob', 'wg_ernr_ssn', 'bic', 'hrg_isu_cd', 'hrg_typ', 'edib_cd', 'oha_daa_cd', 'allgd_disb_onst_dt', 'dli', 'rep_uid', 'hedulvl_cd', 'trml_illness_sw', 'ht_inch', 'wt_lb', 'sex'],
    'appeals.struct_oao': ['reqid', 'hofc_wrk_unit_ac', 'wkld_typ', 'crnt_rqstd_dt', 'critl_case_ctgy_sw', 'clmt_decd_sw', 'dire_need_sw', 'ptntly_homcdl_sw', 'suicidl_sw', 'teri_sw'],
    'appeals.struct_exp': ['reqid', 'hofc_wrk_unit_uid', 'expert_uid', 'schd_sw', 'attndd_sw', 'med_spcly_cd', 'insert_ts', 'dev_grp', 'ackt_rcvdt', 'title', 'fnm', 'mnm', 'lnm', 'sfx']
}

# IFS OAO ETL/Batch Process Settings:
# TIP: Use ONLY forward slashes for paths.
batch_tgt_uid_nm = r'DOCU_CTL_ID'
batch_loop_interval = r'900'
batch_output_fn_fromroot = r'ifs_batch_%s.csv' % datetime.datetime.now().strftime('%m%d%Y_%I%M%S%p')
batch_exp_output_fp_fromroot = r'ifs_batch_exp_%s.csv' % datetime.datetime.now().strftime('%m%d%Y_%I%M%S%p')
# TIP: Max size of (PACAR rows) to process during an individual ETL run:
batch_size = 50
# TIP: Whether to randomize before slicing to the 'batch_size' number:
batch_random = True
# TIP: batch_mp_process_ct be either an integer or 'U'; if 'U', then
# ifs_batch.py will use half of the processing computer's
# total CPUs:
batch_mp_ver = True
batch_mp_process_ct = 'U'
batch_filter_existing_ver = False
batch_savetofile_ver = True
batch_savetodatabase_ver = False

#####################################################################################
# Contents of config_sec.py
######################################################################################

# DMA connection:
dma_pin = get_value_from_env('INSIGHT_DMA_PIN')

# DMA Links
dma_document_retrieval = get_value_from_env('INSIGHT_DMA_DOCUMENT_RETRIEVAL')
dma_logon = get_value_from_env('INSIGHT_DMA_LOGON')
dma_logoff = get_value_from_env('INSIGHT_DMA_LOGOFF')

# Database connection:
doors_cnxn_str = get_value_from_env('INSIGHT_DOORS_CNXN_STR')
reftables_cnxn_str = get_value_from_env('INSIGHT_REFTABLES_CNXN_STR')

# MIDIB database connection:
db2_server = get_value_from_env('INSIGHT_DB2_SERVER')
db2_server_pedib = get_value_from_env('INSIGHT_DB2_SERVER_PEDIB')
midib_hn = get_value_from_env('INSIGHT_MIDIB_HN')
pedib_hn = get_value_from_env('INSIGHT_PEDIB_HN')
midib_port = get_value_from_env('INSIGHT_MIDIB_PORT')
pedib_port = get_value_from_env('INSIGHT_PEDIB_PORT')
midib_uid = get_value_from_env('INSIGHT_MIDIB_UID')
midib_pw = get_value_from_env('INSIGHT_MIDIB_PW')

# DOORS database connection:
pdors_hn = get_value_from_env('INSIGHT_PDORS_HN')
pdors_port = get_value_from_env('INSIGHT_PDORS_PORT')
pdors_dbname = get_value_from_env('INSIGHT_PDORS_DBNAME')
pdors_user = get_value_from_env('INSIGHT_PDORS_USER')
pdors_password = get_value_from_env('INSIGHT_PDORS_PASSWORD')

# schema and Tables
pacar = get_value_from_env('INSIGHT_PACAR')
mhaods_wrkunh = get_value_from_env('INSIGHT_MHAODS_WRKUNH')
malcopy_wrkunh = get_value_from_env('INSIGHT_MALCOPY_WRKUNH')
mhaods_archwkut = get_value_from_env('INSIGHT_MHAODS_ARCHWKUT')
mhaods_parcwkut = get_value_from_env('INSIGHT_MHAODS_PARCWKUT')
mhaods_clminfo = get_value_from_env('INSIGHT_MHAODS_CLMINFO')
mhaods_dispnh = get_value_from_env('INSIGHT_MHAODS_DISPNH')
mhaods_hrgexp = get_value_from_env('INSIGHT_MHAODS_HRGEXP')
mhaods_devlph = get_value_from_env('INSIGHT_MHAODS_DEVLPH')
mhaods_optlexp = get_value_from_env('INSIGHT_MHAODS_OPTLEXP')
medib_case = get_value_from_env('INSIGHT_MEDIB_CASE')
medib_casedoc = get_value_from_env('INSIGHT_MEDIB_CASEDOC')

# case-search API
case_srch_server = get_value_from_env('INSIGHT_CASE_SRCH_SERVER')
case_srch_port = get_value_from_env('INSIGHT_CASE_SRCH_PORT')
case_srch_path = get_value_from_env('INSIGHT_CASE_SRCH_PATH')

# template constants
eview_url = get_value_from_env('INSIGHT_EVIEW_URL')
decision_url = get_value_from_env('INSIGHT_DECISION_URL')

# postgres connection
postgres_hostname = get_value_from_env('INSIGHT_POSTGRES_HOSTNAME')
postgres_port = get_value_from_env('INSIGHT_POSTGRES_PORT')
postgres_dbname = get_value_from_env('INSIGHT_POSTGRES_DBNAME')
postgres_username = get_value_from_env('INSIGHT_POSTGRES_USERNAME')
postgres_password = get_value_from_env('INSIGHT_POSTGRES_PASSWORD')
