# INSIGHT TEXT CLEANER
#
# AUTHOR:
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 09.09.2016
#
# SUMMARY:
# Contains several common text cleaning functions.
#
# WARNING:
# The following is alpha-level/prototype software whose output quality has
# not yet been formally validated and whose documentation is not yet fully
# formed.
# =============================================================================

import logging
import os.path
import re
from string import maketrans

import regex_strings as rs

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
logdir = os.path.join(insightdir, "Log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)

# Perform misc. startup actions:
notranstab = maketrans("", "")


# Correct common spelling errors in a text:
def correct_common_spelling_errors(text):
    try:
        # Dictionaries of known spelling errors (human and otherwise) commonly found in reports.
        regex_spelling_corrections = {r"claimant\ws":"claimant's", r"consultant\ws":"consultant's",
                                      r"examiner\ws":"examiner's", r"child\ws":"child's",
                                      r"individual\ws":"individual's", r"expert\ws":"expert's", r"driver\ws":"driver's",
                                      r"doctor\ws":"doctor's",
                                      r"physician\ws":"physician's", r"widow\ws":"widow's", r"workers\w":"workers'",
                                      r"worker\ws":"worker's"}
        spelling_corrections = {"Fullv Favorable":"Fully Favorable", "ifthe":"if the", " ifit":" if it",
                                "expert'se":"expertise", "ifan":"if an",
                                "pament":"payment", "ffparagraph":"paragraph", "ffsubstantial":"substantial",
                                "ffgainful":"gainful", "ffnot":"not",
                                "activityii":"activity", "activityll":"activity", "activityli":"activity",
                                "severeii":"severe", "severeli":"severe",
                                "thereaiter":"thereafter", "ffmore":"more", "f'mgering":"fingering", "f'mger":"finger",
                                "fmgering":"fingering",
                                "ffvery":"very", "ffmarked":"marked", "seriouslyff":"seriously", "euthymic":"eurythmic",
                                "ffless":"less",
                                "yearsi":"years", "attomey":"attorney", "socialsecurity":"social security",
                                "thejob":"the job", "defmed":"defined",
                                "ofa":"of a", "ofhearing":"of hearing", "ofhow":"of how", "ofthe":"of the",
                                "ofmental":"of mental", "ifit":"if it",
                                "ofthis":"of this", "ofdisapproved":"of disapproved", "of1":"of 1", "of2":"of 2",
                                "of3":"of 3", "of4":"of 4", "of5":"of 5", "of6":"of 6", "of7":"of 7", "of8":"of 8",
                                "of9":"of 9"}

        # The key is the spelling error, and the value is the correction.
        for error, correction in regex_spelling_corrections.iteritems():
            text = re.sub(error, correction, text, flags=re.I)
        for error, correction in spelling_corrections.iteritems():
            text = text.replace(error, correction)
        return text
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Correct both common spelling errors and erroneously replaced 1s in a text:
def final_spelling_corrections(text):
    try:
        # Correct most common (mostly OCR-related) spelling errors:
        text = correct_common_spelling_errors(text)

        # Correct erroneously replaced 1s in SSNs, zip codes, MVRs, and listings in a text:
        def correct_1s_in_text(text, regex, deletion_text=''):
            textres = text
            initial_finditer = re.finditer(regex, text)
            for item in initial_finditer:
                resorig = item.group()
                res = resorig
                if 'l' or '|' in resorig:
                    res_list = []
                    for resorig_item in resorig:
                        if resorig_item == 'l' or resorig_item == '|':
                            res_list.append("1")
                        else:
                            res_list.append(resorig_item)
                    res = "".join(res_list)
                if 'O' in resorig:
                    res_list = []
                    for resorig_item in resorig:
                        if resorig_item == 'O':
                            res_list.append("0")
                        else:
                            res_list.append(resorig_item)
                    res = "".join(res_list)
                    res = res.translate(notranstab, deletion_text)
                textres = textres.replace(resorig, res)
            return textres

        # Dictionary of number search regex's for SSNs, zips, MVRs, and listings with format-specific deletion text
        number_search_regex_dict = {rs.letter_ssn_search_regex:'()-\t\n\r\f\v ',
                                    rs.letter_ssn_search2_regex:'()-\t\n\r\f\v ',
                                    rs.letter_zip_search_regex:'\t\n\r\f\v ', rs.letter_mvr_search_regex:'',
                                    rs.letter_listing_search_regex:''}

        for regex, deletion_text in number_search_regex_dict.iteritems():
            text = correct_1s_in_text(text, regex, deletion_text)

        # Remove errant numeric sequence whitespaces:
        text = remove_num_whitespace(text)

        return text
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Remove whitespace:
def remove_whitespace(text):
    try:
        return ''.join(text.split())
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Remove whitespace in the middle of a number with a dot in its middle:
# TIP: Used to convert (404. 116) into (404.116), primarily to help
# ensure accuracy of nlp_helper.sentence_splitter():
def remove_num_whitespace(text):
    try:
        return re.sub(r'(?<=\d\.) {1,4}(?=\d)', '', text)
    except Exception as err:
        logger.exception('EXCEPTION')
        raise


# Remove margin text as a block (rather than individual components to
# reduce chance non-margin text will be removed):
def remove_see_next_page(text):
    try:
        return re.sub(rs.see_next_page_regex, ' ', text, flags=re.S | re.I)
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Remove margin text as a block AND attempt to normalize any errant newlines
# this might cause:
def remove_see_next_page_and_errnl(text):
    try:
        text = re.sub(rs.see_next_page_regex, ' ', text, flags=re.S | re.I)
        text = re.sub(r"(?<=[a-z])([ \t]*)?([ \n\r\f\v]{2,})(?=[a-z])", " ", text, flags=re.S)
        return text
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Remove margin text as a block as well as in individual components
# in areas where such removals will not likely compromise targeted
# text (e.g. finding heading text):
def remove_margin_text(text):
    try:
        text = re.sub(rs.see_next_page_regex, ' ', text, flags=re.S | re.I)
        text = re.sub(rs.margin_page_number_regex, ' ', text, flags=re.S | re.I)
        text = re.sub(rs.margin_see_next_page_regex, ' ', text, flags=re.S | re.I)
        text = re.sub(rs.letter_ssn_search_regex, ' ', text, flags=re.S | re.I)
        text = re.sub(rs.letter_ssn_search2_regex, ' ', text, flags=re.S | re.I)
        return text
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Normalize spacing:
def normalize_spacing(text):
    try:
        text = ' '.join(text.split())
        return text
    except Exception:
        logger.exception('EXCEPTION')
        raise


# 'Slight cleaner', primarily for decision text/snippet cleaning as it only
# removes margin text in safer block form and then normalizes spacing:
def slight_cleaner(text):
    try:
        text = remove_see_next_page(text)
        text = normalize_spacing(text)
        return text
    except Exception:
        logger.exception('EXCEPTION')
        raise


# 'Slight cleaner findings', primarily for finding heading text cleaning
# as it is a bit more robust to margin text removal in areas
# where it won't affect accuracy:
def slight_cleaner_findings(text):
    try:
        text = remove_margin_text(text)
        text = normalize_spacing(text)
        return text
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Convert text into REGEX so that the text may be more flexibly located:
def convert_to_regex(str_item):
    try:
        str_item = re.escape(str_item)
        str_item = str_item.replace('\\ ', '\\ ?')
        str_item = str_item + '.*'
        str_item = str_item.replace("\\'", '.')
        return str_item
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Removes numbers used in formatting (e.g. "5. I found that...",
# "as defined in 404.1567..."). Used only for ITS ML classifier
# preprocessing.
def remove_format_numbers(text):
    try:
        text = re.sub(r'\d+\.\d+', '', text)
        text = re.sub(r'\d+\.', '', text)
        return text
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Contraction expansion:
def expand_contractions(text):
    try:
        contraction_dict = {"ain't":"am not", "aren't":"are not", "cannot":"can not",
                            "can't":"can not", "could've":"could have", "couldn't":"could not",
                            "couldn't've":"could not have", "didn't":"did not", "doesn't":"does not",
                            "don't":"do not", "hadn't":"had not", "hadn't've":"had not have",
                            "hasn't":"has not", "haven't":"have not", "he'd":"he would",
                            "he'd've":"he would have", "he'll":"he will", "he's":"he is",
                            "how'd":"how would", "how'll":"how will", "how's":"how is", "I'd":"I would",
                            "I'd've":"I would have", "I'll":"I will", "I'm":"I am", "I've":"I have",
                            "isn't":"is not", "it'd":"it would", "it'd've":"it would have",
                            "it'll":"it will", "it's":"it is", "let's":"let us", "ma'am":"madam",
                            "mightn't":"might not", "mightn't've":"might not have",
                            "might've":"might have", "mustn't":"must not", "must've":"must have",
                            "needn't":"need not", "not've":"not have", "o'clock":"of the clock",
                            "oughtn't":"ought not", "shan't":"shall not", "she'd":"she would",
                            "she'd've":"she would have", "she'll":" she will", "she's":"she is",
                            "should've":"should have", "shouldn't":"should not",
                            "shouldn't've":"should not have", "somebody'd":"somebody would",
                            "somebody'd've":"somebody would have", "somebody'll":"somebody will",
                            "somebody's":"somebody is", "someone'd":"someone would",
                            "someone'd've":"someone would have", "someone'll":"someone will",
                            "someone's":"someone is", "something'd":"something would",
                            "something'd've":"something would have", "something'll":"something will",
                            "something's":"something is", "that'll":"that will", "that's":"that is",
                            "there'd":"there would", "there'd've":"there would have",
                            "there're":"there are", "there's":"there is", "they'd":"they would",
                            "they'd've":"they would have", "they'll":"they will", "they're":"they are",
                            "they've":"they have", "'twas":"it was", "wasn't":"was not",
                            "we'd":"we would", "we'd've":"we would have", "we'll":"we will",
                            "we're":"we are", "we've":"we have", "weren't":"were not",
                            "what'll":"what will", "what're":"what are", "what's":"what is / what does",
                            "what've":"what have", "when's":"when is", "where'd":"where did",
                            "where's":"where is", "where've":"where have", "who'd":"who had",
                            "who'd've":"who would have", "who'll":"who will", "who're":"who are",
                            "who's":"who is", "who've":"who have", "why'll":"why will",
                            "why're":"why are", "why's":"why is", "won't":"will not",
                            "would've":"would have", "wouldn't":"would not",
                            "wouldn't've":"would not have", "y'all":"you all", "y'all'll":"you all will",
                            "you'd":"you would", "you'd've":"you would have", "you'll":"you will",
                            "you're":"you are", "you've":"you have"}

        for key, val in contraction_dict.iteritems():
            key = r'\b' + key + r'\b'
            text = re.sub(key, val, text, flags=re.I)
        return text
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Normalize text for use in UMLS term identification:
def normalize_with_underscores(text):
    try:
        return '_' + text.replace(' ', '_').replace(',', '_,').replace(';', '_;').replace(':', '_:').replace('.',
                                                                                                             '_.') + '_'
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Word/phrase inversion on comma for use in UMLS MDI parsing:
def invert_around_comma(text):
    try:
        return ' '.join(text.split(', ')[::-1])
    except Exception:
        logger.exception('EXCEPTION')
        raise
