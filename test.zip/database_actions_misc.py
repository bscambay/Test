# INSIGHT FULL SUITE - DART DATABASE RETRIEVAL ACTIONS
#
# AUTHOR:
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 01.30.2017
#
# SUMMARY:
# Contains functions designed to retrieve data from the DART database.
#
#
# WARNING:
# The following is alpha-level/prototype software whose output quality has
# not yet been formally validated and whose documentation is not yet fully
# formed.
# =============================================================================

# Import modules:
import logging
import os.path
import sys

import ibm_db
import pandas
import psycopg2

import config as cfg

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
templatesdir = os.path.join(insightdir, "Templates")
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")
staticdir = os.path.join(insightdir, "static")
tempdir = os.path.join(insightdir, "temp")
viewsdir = os.path.join(insightdir, "views")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)

# Perform misc. setup actions:
pandas.options.mode.chained_assignment = None


# Retrieve DOORS data (SSO / office code for now) from DOORS via zip code input:
def retrieve_doors(input_zip5):
    try:
        # Check argument:
        if not isinstance(input_zip5, str) or not input_zip5.isdigit() or len(input_zip5) != 5:
            return 'E'
        # Query DOORS DB for latest SSO/OCD associated with this zip:
        conn_string = "host='%s' port='%s' dbname='%s' user='%s' password='%s'" % (
            cfg.pdors_hn, cfg.pdors_port, cfg.pdors_dbname, cfg.pdors_user, cfg.pdors_password)
        conn = psycopg2.connect(conn_string)
        cursor_SQLNLP = conn.cursor()
        sql = "select ocd from PDORS_QRY.V3_FOZIPCD_DIM where zip5 ='%s'" % input_zip5
        cursor_SQLNLP.execute(sql)
        restup = cursor_SQLNLP.fetchone()
        cursor_SQLNLP.close()
        del cursor_SQLNLP
        conn.close()
        # Parse result:
        if not restup:
            return 'U'
        res_ocd = restup[0]
        return res_ocd
    except Exception:
        logger.exception('EXCEPTION')
        return 'E'


# Retrieve self-reported height, weight, and sex for a given claimant/case
# from MIDIB/MEDIB.CASE using the case's EFLDR_NUM (TIP: BATCH CAPABLE):
def retrieve_htwt_casedata(input_efldr_num_list):
    '''Retrieve self-reported height and weight data, as well as
    sex data, for a given claimant/case from the MEDIB/MIDIB CASE
    table using an EFLDR_NUM associated with that claimant. Primarily
    used to enable parsing/interpreting of claimant self-reported
    weight/BMI.

    NOTE (03.13.2017): A study of MIDIB.CASE indicates that for
    a given EFLDR_NUM value, there is an ~40% likelihood that
    height and weight values will be present; sex entries always
    present (based on first 500K entries).  In part this is because
    the same EFLDR_NUM can appear multiple times, with only the obs
    corresponding to the initial level containing height/weight values.

    USAGE EXAMPLE (single input):
    >>> input_efldr_num_list_singleobs = ['123456789']
    >>> res_df = retrieve_htwt_casedata(input_efldr_num_list_singleobs)
    >>> res_dict = resdf.loc[resdf['EFLDR_NUM'] == input_efldr_num_list_singleobs[0]].iloc[0].to_dict()
    >>> merged_dict = dict(old_dict.items() + res_dict.items())

    USAGE EXAMPLE (multiple inputs):
    >>> input_efldr_num_list_multiobs = old_df['EFLDR_NUM'].tolist()
    >>> res_df = retrieve_htwt_casedata(input_efldr_num_list_multiobs)
    >>> merged_df = old_df.merge(res_df, on='EFLDR_NUM', how='left')

    Args:
        input_efldr_num_list {list}: FLDR_NUM value(s) associated with
            the targeted claimant (each as a string).
    Returns:
        resdf_final {pandas DataFrame}: A DataFrame whose columns
            are as follows:
            - 'EFLDR_NUM' {str}: The folder number associated with the
            observation.  Equivalent to the MIDIB.CASE 'FLDR_NUM'.
            - 'HT_INCH': The claimant's height in inches {str}, or 'E'
            where an exception occurred during retrieval, or 'U' where
            no value could be found.
            - 'WT_LB': The claimant's weight in pounds {str}, or 'E'
            where an exception occurred during retrieval, or 'U' where
            no value could be found.
            - 'SEX': The claimant's sex as 'M' or 'F' {str}, or 'E'
            where an exception occurred during retrieval, or 'U' where
            no value could be found.
    Raises:
        N/A (if exception occurs, will return an 'E' {str}).'''
    try:

        # Check argument:
        if not isinstance(input_efldr_num_list, list):
            raise Exception

        # Establish MIDIB connection:
        db_cnxn_str = "DATABASE=%s;HOSTNAME=%s;PORT=%s;PROTOCOL=TCPIP;UID=%s;PWD=%s;" % (
            cfg.db2_server_pedib, cfg.pedib_hn, cfg.pedib_port, cfg.midib_uid, cfg.midib_pw)
        conn = ibm_db.connect(db_cnxn_str, "", "")

        # Execute SQL statement:
        sql = "SELECT FLDR_NUM, HT_INCH, WT_OUNCES, SEX FROM MIDIB.CASE WHERE FLDR_NUM IN (%s)" % ', '.join(
            [str(e) for e in input_efldr_num_list])
        stmt = ibm_db.exec_immediate(conn, sql)

        # Iterate through result statement to return a dictionary
        # for each observation:
        resultlist = []
        while stmt:
            result = ibm_db.fetch_assoc(stmt)
            if result is False:
                break
            else:
                resultlist.append(result)

        # Close connection:
        ibm_db.close(conn)

        # Place results in dataframe:
        resdf = pandas.DataFrame(resultlist)

        # Parse database results:
        # TIP: Study shows that nearly all resulting
        # observations in 'resdf' will exhibit a pattern of either
        # having both a HT_INCH and WT_OUNCES value or having NaN for
        # both. Thus, simple approach is to limit to non-NaN observations,
        # then generate additional 'U' observations for any input EFLDR_NUM
        # values that were dropped/did not have any non-NaN observations:
        resdf_nonull = resdf.loc[
            (resdf['HT_INCH'].notnull()) & (resdf['WT_OUNCES'].notnull()) & (resdf['SEX'].notnull())]
        resdf_nonull.drop_duplicates(subset='FLDR_NUM', keep='first', inplace=True)
        resdf_nonull_fldrnum_set = set(resdf_nonull['FLDR_NUM'].tolist())
        input_efldr_num_list_set = set(input_efldr_num_list)
        fldrnum_remaining = list(input_efldr_num_list_set - resdf_nonull_fldrnum_set)
        fldrnum_remaining_dictlist = []
        for fldrnum in fldrnum_remaining:
            fldrnum_dict = {}
            fldrnum_dict['FLDR_NUM'] = fldrnum
            fldrnum_dict['HT_INCH'] = 'U'
            fldrnum_dict['WT_OUNCES'] = 'U'
            fldrnum_dict['SEX'] = 'U'
            fldrnum_remaining_dictlist.append(fldrnum_dict)
        fldrnum_remaining_df = pandas.DataFrame(fldrnum_remaining_dictlist)
        resdf_final = pandas.concat([resdf_nonull, fldrnum_remaining_df], ignore_index=True)

        # Transform each observation's final results:
        resdf_final['EFLDR_NUM'] = resdf_final['FLDR_NUM']

        def transform_ht(x):
            return str(x).strip()

        resdf_final['HT_INCH'] = resdf_final['HT_INCH'].apply(lambda x: transform_ht(x))

        def transform_wt(x):
            if x == 'U':
                return 'U'
            else:
                wt_res = float(x) / 16
                return str(wt_res).strip()

        resdf_final['WT_LB'] = resdf_final['WT_OUNCES'].apply(lambda x: transform_wt(x))

        def transform_sex(x):
            return str(x).strip()

        resdf_final['SEX'] = resdf_final['SEX'].apply(lambda x: transform_sex(x))

        resdf_final.drop(labels=['WT_OUNCES', 'FLDR_NUM'], axis=1, inplace=True)

        # Return resulting observation(s):
        return resdf_final

    except Exception:
        logger.exception('EXCEPTION')
        try:
            ibm_db.close(conn)
        except Exception:
            pass
        return 'E'
