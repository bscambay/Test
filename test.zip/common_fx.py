# INSIGHT COMMON FUNCTIONS
#
# AUTHOR:
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 01.15.2017
#
# SUMMARY:
# A collection of miscellaneous functions used by INSIGHT.
#
# WARNING:
# The following is alpha-level/prototype software whose output quality has
# not yet been formally validated and whose documentation is not yet fully
# formed.
# =============================================================================

# Import modules:
import collections
import logging
import os.path

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
logdir = os.path.join(insightdir, "Log")
datadir = os.path.join(insightdir, "Data")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


# Flatten irregular list of lists:
def flatten_irreg(input_list):
    '''
    Flattens a list of object, some of which may be iterables, of
    arbitrary depth.

    Example:
    >>> flatten_res = flatten_irreg([1,2,[3,4],(5,6),7])
    >>> list(flatten_res)
    >>> [1, 2, 3, 4, 5, 6, 7]

    TIP: If exception occurs, iterator will stop, and an attempt to
    call 'list()' on the generator object will throw the generator-
    breaking exception.

    TIP: If dictionary object in list, its keys will be returned.

    Args:
        input_list {list}: List object to be parsed.

    Returns:
        - Flattened list (i.e. not containing any elements that are lists).
        - 'E' {str}: An exception occurred.
    Raises:
        N/A.
    '''
    try:
        for el in input_list:
            # TIP: If iterable and NOT a string (so that it doesn't separate a
            # string into characters):
            if isinstance(el, collections.Iterable) and not isinstance(el, basestring):
                for sub in flatten_irreg(el):
                    yield sub
            else:
                yield el
    except Exception:
        logger.exception('EXCEPTION')
