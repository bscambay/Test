import ast
import re
import logging
import sys
import os
from string import maketrans

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


scrdir = os.path.abspath(os.path.join(os.path.dirname(__file__),"../../src"))
sys.path.insert(0, scrdir)
import iqrgenerator_common_calcs as ifsiqrcc

'''
sys.path.insert(0, "../../src")
import iqrgenerator_common_calcs as ifsiqrcc
'''
class createflag(object):

    def __init__(self, **iqrepgen_dict):
        self.iqrepgen_dict = iqrepgen_dict

    #Seperated this from the createflagtext_selfcontained to make it cleaner
    def check_ver(self, ver):
        if ver == '0':
            flagtxt = "&#x2714;"
        elif ver.startswith("P"):
            flagtxt = "Unknown"
        elif ver.startswith("U"):
            flagtxt = "Unknown"
        elif ver.startswith("E"):
            flagtxt = "Error - Internal"
        else:
            flagtxt = "Error - Unknown Data Point Value (Value: " + ver + ")"
        return flagtxt


    def createflagtext_selfcontained(self, varnm, valpresent):
        notranstab = maketrans("", "")
        try:
            vernm = varnm + "_ver"
            ver = self.iqrepgen_dict[vernm]
            if ver == "1":
                if valpresent == "1":
                    try:
                        # Gather all 'quality.val' entries:
                        valnm = varnm + "_val"
                        val_resdictlist = ifsiqrcc.gather_quality_val(self.iqrepgen_dict['quality'], valnm)
                        val_reslist_cleaned = []
                        for resd in val_resdictlist:
                            val = resd['val']
                            val = str(val)
                            val = val.translate(notranstab, "[]")
                            val = val.strip()
                            val = re.sub(r"^(\"|')", "", val)
                            val = re.sub(r"(\"|')$", "", val)
                            val = val.replace("', '", ", ")
                            val = val.replace("(TEXT=", "&nbsp;&nbsp;(TEXT=")
                            val_reslist_cleaned.append(val)
                        flagtxt = "&#x2718; " + " / ".join(val_reslist_cleaned)
                    except Exception as x:
                        flagtxt = "&#x2718; (Error - Cannot Retrieve Flag Value Text [Error Message: " + str(
                            x) + "])"
                    return flagtxt
                else:
                    flagtxt = "&#x2718;"
                    return flagtxt
            else:
                flagtxt = self.check_ver(ver)
                return flagtxt
        except KeyError:
            flagtxt = "Error - Structured Data Not Linked"
            return flagtxt
        except Exception:
            logger.exception('EXCEPTION')
            flagtxt = "Error - Insight Quality Report Generation Script Error"
            return flagtxt


    def createflagtext_nonselfcontained(self, varnm, valpresent):
        try:
            # Step 1:

            # Step 2:
            if varnm == "flag_s2mdi_selfwt":
                try:
                    vernm = varnm + "_ver"
                    ver = self.iqrepgen_dict[vernm]
                    valnm = varnm + "_val"
                    if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(
                            ver.startswith("E")):
                        flagtxt = self.createflagtext_selfcontained(varnm, valpresent)
                        return flagtxt
                    else:
                        flag_resdictlist = ifsiqrcc.gather_quality_val(self.iqrepgen_dict['quality'], valnm)
                        if not flag_resdictlist:
                            return "Error - Unable to Retrieve Quality Flag Details"
                        else:
                            flag_htmlreslist = []
                            for resd in flag_resdictlist:
                                resd_val = resd['val']
                                resd_val = resd_val.replace("color:#ce0000", "color:#9900cc")
                                flag_htmlreslist.append(resd_val)
                            flag_htmlreslist_txt = ' / '.join(flag_htmlreslist)
                            flag_htmlreslist_txt = "&#x2718; " + flag_htmlreslist_txt
                            comp = re.compile('<.*?>')
                            flag_htmlreslist_txt = re.sub(comp, '', flag_htmlreslist_txt)
                            return  flag_htmlreslist_txt
                except Exception:
                    logger.exception('EXCEPTION')
                    return "Error - Unknown INSIGHT Quality Report Generation Error"

            # Step 3 Meets/Equals:

            # Step 3 Functionally Equals:

            # RFC:
            elif varnm == "flag_rfc_logicconflict":
                try:
                    vernm = varnm + "_ver"
                    ver = self.iqrepgen_dict[vernm]
                    valnm = varnm + "_val"
                    if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(
                            ver.startswith("E")):
                        flagtxt = self.createflagtext_selfcontained(varnm, valpresent)
                        return flagtxt
                    else:
                        flag_resdictlist = ifsiqrcc.gather_quality_val(self.iqrepgen_dict['quality'], valnm)
                        if not flag_resdictlist:
                            return "Error - Unable to Retrieve Quality Flag Details"
                        else:
                            flag_htmlreslist = []
                            for resd in flag_resdictlist:
                                resd_val = resd['val']
                                logicconflict_transdict = {
                                    "1": "Claimant's capacities to sit, stand, and walk total less than 8 hours",
                                    "2": "Sedentary exertion paired with a finding that the claimant cannot stoop"}
                                if resd_val in logicconflict_transdict:
                                    flag_htmlreslist.append(logicconflict_transdict[resd_val])
                            flag_htmlreslist_txt = ' / '.join(flag_htmlreslist)
                            flag_htmlreslist_txt = "&#x2718; " + flag_htmlreslist_txt
                            return flag_htmlreslist_txt
                except Exception:
                    logger.exception('EXCEPTION')
                    return "Error - Unknown INSIGHT Quality Report Generation Error"

            # Step 4:
            elif varnm == "flag_s4dotrfc":
                try:
                    vernm = varnm + "_ver"
                    ver = self.iqrepgen_dict[vernm]
                    if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(
                            ver.startswith("E")):
                        flagtxt = self.createflagtext_selfcontained(varnm, valpresent)
                        return flagtxt
                    else:
                        # Begin custom flag text creation for 'flag_s4dotrfc_conflict':

                        valnm = varnm + "_val"
                        flag_resdictlist = ifsiqrcc.gather_quality_val(self.iqrepgen_dict['quality'], valnm)
                        if not flag_resdictlist:
                            return "Error - Unable to Retrieve Quality Flag Details"
                        else:
                            flag_s4dotrfc_alls4obs_htmlreslist = []
                            for resd in flag_resdictlist:
                                resd_val = resd['val']
                                if isinstance(resd_val, str):
                                    resd_val = ast.literal_eval(resd_val)
                                # TIP: Example resd: {'569686046': ['rfcreachlol=N vs dotreachlol=O'], '311472010': ['rfcreachlol=F vs dotreachlol=C',
                                # 'rfchandlelol=F vs dothandlelol=C', 'rfcfingerlol=F vs dotfingerlol=C', 'rfcfeellol=F vs dotfeellol=C']}
                                # TIP: Target output:
                                # """
                                # 569686046: RFC reach capacity level = never, but DOT reach capacity level = occasional
                                # <br>
                                # 311472010: RFC reach capacity level = frequent, but DOT reach capacity level = constant;
                                # RFC handle capacity level = frequent, but DOT handle capacity level = constant
                                # """
                                flag_s4dotrfc_val_combined = []
                                for k, v in resd_val.iteritems():
                                    conflict_trans_list = []
                                    for conflict in v:
                                        try:
                                            conflicttrans = ""
                                            rfcflagval = conflict.split(" vs ")[0]
                                            rfcflagval_FA_RAW = rfcflagval.split("=")[0]
                                            rfcflagval_FA = rfcflagval_FA_RAW[3:]
                                            rfcflagval_FA = rfcflagval_FA[:-3]
                                            rfcflagval_FA = ifsiqrcc.translate_rfc_fa(rfcflagval_FA)
                                            conflicttrans += str("RFC " + rfcflagval_FA + " capacity level = ")
                                            rfcflagval_LOL = rfcflagval.split("=")[1]
                                            if '; ' in rfcflagval_LOL:
                                                rfcflagval_LOL = rfcflagval_LOL.split('; ')
                                                rfcflagval_LOL = ', '.join(
                                                    [ifsiqrcc.translate_rfc_lol(el) for el in rfcflagval_LOL])
                                            else:
                                                rfcflagval_LOL = ifsiqrcc.translate_rfc_lol(rfcflagval_LOL)
                                            conflicttrans += str(
                                                rfcflagval_LOL + ", but DOT " + rfcflagval_FA + " capacity level = ")

                                            dotflagval = conflict.split(" vs ")[1]
                                            dotflagval_LOL = dotflagval.split("=")[1]
                                            if '[' in dotflagval_LOL:
                                                dotflagval_LOL = ast.literal_eval(dotflagval_LOL)
                                                dotflagval_LOL = ', '.join(
                                                    [ifsiqrcc.translate_rfc_lol(el) for el in dotflagval_LOL])
                                            else:
                                                dotflagval_LOL = ifsiqrcc.translate_rfc_lol(dotflagval_LOL)
                                            conflicttrans += dotflagval_LOL
                                            conflict_trans_list.append(conflicttrans)
                                        except Exception:
                                            logger.exception('EXCEPTION')
                                            conflict_trans_list.append(conflict)

                                    conflict_trans_list_joined = "; ".join(conflict_trans_list)
                                    flagstr = "DOT " + k + ": " + conflict_trans_list_joined
                                    flag_s4dotrfc_val_combined.append(flagstr)

                                flag_s4dotrfc_alls4obs_htmlreslist.append("<br>".join(flag_s4dotrfc_val_combined))

                            flag_s4dotrfc_alls4obs_html = "<br><br>".join(flag_s4dotrfc_alls4obs_htmlreslist)
                            flag_s4dotrfc_alls4obs_html = "&#x24be; <br>" + flag_s4dotrfc_alls4obs_html
                            return flag_s4dotrfc_alls4obs_html
                except Exception:
                    logger.exception('EXCEPTION')
                    logger.critical(self.iqrepgen_dict['flag_s4dotrfc_ver'])
                    return "Error - Unknown INSIGHT Quality Report Generation Error"

            # Step 5:

            # flag_s5dotrfc_conflict:
            elif varnm == "flag_s5dotrfc":
                try:
                    vernm = varnm + "_ver"
                    ver = self.iqrepgen_dict[vernm]
                    if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(
                            ver.startswith("E")):
                        flagtxt = self.createflagtext_selfcontained(varnm, valpresent)
                        return flagtxt
                    else:
                        valnm = varnm + "_val"
                        flag_resdictlist = ifsiqrcc.gather_quality_val(self.iqrepgen_dict['quality'], valnm)
                        if not flag_resdictlist:
                            return "Error - Unable to Retrieve Quality Flag Details"
                        else:
                            flag_s5dotrfc_alls5obs_htmlreslist = []
                            for resd in flag_resdictlist:
                                resd_val = resd['val']
                                if isinstance(resd_val, str):
                                    resd_val = ast.literal_eval(resd_val)
                                # TIP: Example resd: {'569686046': ['rfcreachlol=N vs dotreachlol=O'], '311472010': ['rfcreachlol=F vs dotreachlol=C', 'rfchandlelol=F vs dothandlelol=C', 'rfcfingerlol=F vs dotfingerlol=C', 'rfcfeellol=F vs dotfeellol=C']}
                                # TIP: Target output:
                                # """
                                # 569686046: RFC reach capacity level = never, but DOT reach capacity level = occasional
                                # <br>
                                # 311472010: RFC reach capacity level = frequent, but DOT reach capacity level = constant; RFC handle capacity level = frequent, but DOT handle capacity level = constant
                                # """
                                flag_s5dotrfc_val_combined = []
                                for k, v in resd_val.iteritems():
                                    conflict_trans_list = []
                                    for conflict in v:
                                        try:
                                            conflicttrans = ""
                                            rfcflagval = conflict.split(" vs ")[0]
                                            rfcflagval_FA_RAW = rfcflagval.split("=")[0]
                                            rfcflagval_FA = rfcflagval_FA_RAW[3:]
                                            rfcflagval_FA = rfcflagval_FA[:-3]
                                            rfcflagval_FA = ifsiqrcc.translate_rfc_fa(rfcflagval_FA)
                                            conflicttrans += str("RFC " + rfcflagval_FA + " capacity level = ")
                                            rfcflagval_LOL = rfcflagval.split("=")[1]
                                            if '; ' in rfcflagval_LOL:
                                                rfcflagval_LOL = rfcflagval_LOL.split('; ')
                                                rfcflagval_LOL = ', '.join(
                                                    [ifsiqrcc.translate_rfc_lol(el) for el in rfcflagval_LOL])
                                            else:
                                                rfcflagval_LOL = ifsiqrcc.translate_rfc_lol(rfcflagval_LOL)
                                            conflicttrans += str(
                                                rfcflagval_LOL + ", but DOT " + rfcflagval_FA + " capacity level = ")

                                            dotflagval = conflict.split(" vs ")[1]
                                            dotflagval_LOL = dotflagval.split("=")[1]
                                            if '[' in dotflagval_LOL:
                                                dotflagval_LOL = ast.literal_eval(dotflagval_LOL)
                                                dotflagval_LOL = ', '.join(
                                                    [ifsiqrcc.translate_rfc_lol(el) for el in dotflagval_LOL])
                                            else:
                                                dotflagval_LOL = ifsiqrcc.translate_rfc_lol(dotflagval_LOL)
                                            conflicttrans += dotflagval_LOL
                                            conflict_trans_list.append(conflicttrans)
                                        except Exception:
                                            logger.exception('EXCEPTION')
                                            conflict_trans_list.append(conflict)

                                    conflict_trans_list_joined = "; ".join(conflict_trans_list)
                                    flagstr = "DOT " + k + ": " + conflict_trans_list_joined
                                    flag_s5dotrfc_val_combined.append(flagstr)

                                flag_s5dotrfc_alls5obs_htmlreslist.append("<br>".join(flag_s5dotrfc_val_combined))

                            flag_s5dotrfc_alls5obs_html = "<br><br>".join(flag_s5dotrfc_alls5obs_htmlreslist)
                            flag_s5dotrfc_alls5obs_html = "&#x2718; <br>" + flag_s5dotrfc_alls5obs_html
                            return flag_s5dotrfc_alls5obs_html
                except Exception:
                    logger.exception('EXCEPTION')
                    return "Error - Unknown INSIGHT Quality Report Generation Error"

            # flag_s5bordage:
            elif varnm == "flag_s5bordage":
                try:
                    vernm = varnm + "_ver"
                    ver = self.iqrepgen_dict[vernm]
                    if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(
                            ver.startswith("E")):
                        flagtxt = self.createflagtext_selfcontained(varnm, valpresent)
                        return flagtxt
                    else:
                        valnm = varnm + "_val"
                        flag_resdictlist = ifsiqrcc.gather_quality_val(self.iqrepgen_dict['quality'], valnm)
                        if not flag_resdictlist:
                            return "Error - Unable to Retrieve Quality Flag Details"
                        else:
                            flag_htmlreslist = []
                            for resd in flag_resdictlist:
                                mvr_reslist = []
                                resd_val_split = resd['val'].split('; ')
                                for resd_val_mvr in resd_val_split:
                                    mvr_reslist.append(resd_val_mvr)

                                struct_age_paiend = self.iqrepgen_dict['STRUCT_AGEREL_PAIEND']
                                paiend = self.iqrepgen_dict['paiend']
                                # NOTE: Ok, so at this juncture your IQ result for flag_s5mvrbordage may entail a semicolon-divided STRUCT_AGEREL_PAIEND,
                                # e.g. "25-y-6-m (T2 DIB); 32-y-1-m (T16 SSI)".	 You'll need to be cognizant of that fact here.	 But for now,
                                # I'll simply output the value, semicolon or no.
                                flag_s5mvrbordage_HTML_text = "Claimant age at end of PAI (%s): %s vs. borderline MVR(s): %s" % (
                                    paiend, struct_age_paiend, '; '.join(mvr_reslist))
                                flag_htmlreslist.append(flag_s5mvrbordage_HTML_text)
                            flag_htmlreslist_txt = ' / '.join(flag_htmlreslist)
                            flag_htmlreslist_txt = "&#x2718; " + flag_htmlreslist_txt
                            return flag_htmlreslist_txt
                except Exception:
                    logger.exception('EXCEPTION')
                    return "Error - Unknown INSIGHT Quality Report Generation Error"

            # flag_s5mvrrfcexlvl:
            elif varnm == "flag_s5mvrrfcexlvl":
                try:
                    vernm = varnm + "_ver"
                    ver = self.iqrepgen_dict[vernm]
                    valnm = varnm + "_val"
                    if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(
                            ver.startswith("E")):
                        flagtxt = self.createflagtext_selfcontained(varnm, valpresent)
                        return flagtxt
                    else:
                        flag_resdictlist = ifsiqrcc.gather_quality_val(self.iqrepgen_dict['quality'], valnm)
                        if not flag_resdictlist:
                            return "Error - Unable to Retrieve Quality Flag Details"
                        else:
                            rfcfitexlvl_strdict = {"F": "Full", "H": "Heavy", "M": "Medium", "L": "Light",
                                                   "S": "Sedentary"}
                            flag_htmlreslist = []
                            for resd in flag_resdictlist:
                                resd_val_split = resd['val'].split(' vs ')
                                rfcexlvl_list = ast.literal_eval(resd_val_split[0])
                                rfcexlvl_list_trans_str = '; '.join(
                                    [rfcfitexlvl_strdict[exlvl] for exlvl in rfcexlvl_list])
                                mvr_list_trans_str = '; '.join(ast.literal_eval(resd_val_split[1]))
                                resd_val_str = "RFC Exertional Level(s): " + rfcexlvl_list_trans_str + " vs MVR(s): " + mvr_list_trans_str
                                flag_htmlreslist.append(resd_val_str)
                            flag_htmlreslist_txt = ' / '.join(flag_htmlreslist)
                            flag_htmlreslist_txt = "&#x2718; " + flag_htmlreslist_txt
                            return flag_htmlreslist_txt
                except Exception:
                    logger.exception('EXCEPTION')
                    return "Error - Unknown INSIGHT Quality Report Generation Error"

            # flag_s5mvragepai:
            elif varnm == "flag_s5mvragepai":
                try:
                    vernm = varnm + "_ver"
                    ver = self.iqrepgen_dict[vernm]
                    valnm = varnm + "_val"
                    if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(
                            ver.startswith("E")):
                        flagtxt = self.createflagtext_selfcontained(varnm, valpresent)
                        return flagtxt
                    else:
                        flag_resdictlist = ifsiqrcc.gather_quality_val(self.iqrepgen_dict['quality'], valnm)
                        if not flag_resdictlist:
                            return "Error - Unable to Retrieve Quality Flag Details"
                        else:
                            struct_agerel_paistart = self.iqrepgen_dict["STRUCT_AGEREL_PAISTART"]
                            struct_agerel_paistart_year = re.search(r"^\d+", struct_agerel_paistart).group()
                            struct_agerel_paiend = self.iqrepgen_dict["STRUCT_AGEREL_PAIEND"]
                            struct_agerel_paiend_year = re.search(r"^\d+", struct_agerel_paiend).group()
                            flag_htmlreslist = []
                            for resd in flag_resdictlist:
                                resd_val = resd['val']
                                resd_val_str = "Claimant Age Range: " + struct_agerel_paistart_year + "-" + struct_agerel_paiend_year + " vs MVR(s): " + resd_val
                                flag_htmlreslist.append(resd_val_str)
                            flag_htmlreslist_txt = ' / '.join(flag_htmlreslist)
                            flag_htmlreslist_txt = "&#x2718; " + flag_htmlreslist_txt
                            return flag_htmlreslist_txt
                except Exception:
                    logger.exception('EXCEPTION')
                    return "Error - Unknown INSIGHT Quality Report Generation Error"

            # flag_s5mvragepaiend:
            elif varnm == "flag_s5mvragepaiend":
                try:
                    vernm = varnm + "_ver"
                    ver = self.iqrepgen_dict[vernm]
                    valnm = varnm + "_val"
                    if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(
                            ver.startswith("E")):
                        flagtxt = self.createflagtext_selfcontained(varnm, valpresent)
                        return flagtxt
                    else:
                        flag_resdictlist = ifsiqrcc.gather_quality_val(self.iqrepgen_dict['quality'], valnm)
                        if not flag_resdictlist:
                            return "Error - Unable to Retrieve Quality Flag Details"
                        else:
                            struct_agerel_paiend = self.iqrepgen_dict["STRUCT_AGEREL_PAIEND"]
                            struct_agerel_paiend_year = re.search(r"^\d+", struct_agerel_paiend).group()
                            flag_htmlreslist = []
                            for resd in flag_resdictlist:
                                resd_val = resd['val']
                                resd_val_str = "Claimant Age at End of PAI: " + struct_agerel_paiend_year + " vs MVR(s): " + resd_val
                                flag_htmlreslist.append(resd_val_str)
                            flag_htmlreslist_txt = ' / '.join(flag_htmlreslist)
                            flag_htmlreslist_txt = "&#x2718; " + flag_htmlreslist_txt
                            return flag_htmlreslist_txt
                except Exception:
                    logger.exception('EXCEPTION')
                    return "Error - Unknown INSIGHT Quality Report Generation Error"

            # flag_s5mvred:
            elif varnm == "flag_s5mvred":
                try:
                    vernm = varnm + "_ver"
                    ver = self.iqrepgen_dict[vernm]
                    valnm = varnm + "_val"
                    if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(
                            ver.startswith("E")):
                        flagtxt = self.createflagtext_selfcontained(varnm, valpresent)
                        return flagtxt
                    else:
                        flag_resdictlist = ifsiqrcc.gather_quality_val(self.iqrepgen_dict['quality'], valnm)
                        if not flag_resdictlist:
                            return "Error - Unable to Retrieve Quality Flag Details"
                        else:
                            edver_val_translation_dict = {"I": "Illiterate", "M": "Marginal", "L": "Limited",
                                                          "H": "High School"}

                            flag_htmlreslist = []
                            for resd in flag_resdictlist:
                                resd_val = resd['val']
                                edver = self.iqrepgen_dict['edver']
                                edver_split = edver.split('; ')
                                edver_trans = ' '.join([edver_val_translation_dict[ev] for ev in edver_split])
                                # edver_trans = edver_val_translation_dict[edver]
                                resd_val_str = "Education level(s) found: " + edver_trans + " vs MVR(s): " + resd_val
                                flag_htmlreslist.append(resd_val_str)
                            flag_htmlreslist_txt = ' / '.join(flag_htmlreslist)
                            flag_htmlreslist_txt = "&#x2718; " + flag_htmlreslist_txt
                    return flag_htmlreslist_txt  # TESTING
                except Exception:
                    logger.exception('EXCEPTION')
                    return "Error - Unknown INSIGHT Quality Report Generation Error"

            # flag_s5mvrtx:
            elif varnm == "flag_s5mvrtx":
                try:
                    vernm = varnm + "_ver"
                    ver = self.iqrepgen_dict[vernm]
                    valnm = varnm + "_val"
                    if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(
                            ver.startswith("E")):
                        flagtxt = self.createflagtext_selfcontained(varnm, valpresent)
                        return flagtxt
                    else:
                        flag_resdictlist = ifsiqrcc.gather_quality_val(self.iqrepgen_dict['quality'], valnm)
                        if not flag_resdictlist:
                            return "Error - Unable to Retrieve Quality Flag Details"
                        else:
                            txskillsver_strdict = {"1": "Yes TX Skills", "2": "No TX Skills",
                                                   "3": "TX Skills Not An Issue/Material"}
                            flag_htmlreslist = []
                            for resd in flag_resdictlist:
                                resd_val = resd['val']
                                txskillsver = self.iqrepgen_dict['txskillsver']
                                txskillsver_trans = txskillsver_strdict[txskillsver]
                                resd_val_str = "Transferability finding: " + txskillsver_trans + " vs MVR(s): " + resd_val
                                flag_htmlreslist.append(resd_val_str)
                            flag_htmlreslist_txt = ' / '.join(flag_htmlreslist)
                            flag_htmlreslist_txt = "&#x2718; " + flag_htmlreslist_txt
                            return flag_htmlreslist_txt
                except Exception:
                    logger.exception('EXCEPTION')
                    return "Error - Unknown INSIGHT Quality Report Generation Error"

            # If none of these matched, return error text:
            else:
                err_str = "Error - iqrgenerator.createflagtext_nonselfcontained() could not locate parser for 'iqvarnm' (%s)" % varnm
                logger.critical(err_str)
                return "Error - Unable to Retrieve Quality Flag Details"
        except Exception:
            logger.exception('EXCEPTION')
            return "Error - Unable to Retrieve Quality Flag Details"
        # (DEVELOPMENT) Create RFC/DOT table:
        # TODO: Generalize this so that it works for Step 5 DOT/RFC conflict table generation:
